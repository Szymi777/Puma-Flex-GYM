<?php
/**
 * includes/db.php
 * Centralne połączenie z bazą danych przez PDO.
 * PDO zapewnia Prepared Statements (ochrona przed SQL Injection).
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'pumaflex');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

$dsn = 'mysql:host=' . DB_HOST
     . ';dbname=' . DB_NAME
     . ';charset=' . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // rzuca wyjątki przy błędach
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // wyniki jako tablice asocjacyjne
    PDO::ATTR_EMULATE_PREPARES   => false,                    // prawdziwe prepared statements
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // W środowisku produkcyjnym: loguj błąd, nie wyświetlaj szczegółów
    error_log('Błąd połączenia z bazą: ' . $e->getMessage());
    http_response_code(503);
    die('Serwis tymczasowo niedostępny. Spróbuj ponownie za chwilę.');
}