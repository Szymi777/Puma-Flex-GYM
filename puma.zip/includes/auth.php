<?php
/**
 * includes/auth.php
 * Helper: funkcje sesji i uprawnień.
 * Dołączany na początku każdego pliku wymagającego autentykacji.
 */

if (session_status() === PHP_SESSION_NONE) {
    // Bezpieczne ustawienia sesji (przed session_start)
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Strict');
    session_start();
}

/**
 * Sprawdza czy użytkownik jest zalogowany.
 * Jeśli nie – przekierowuje na stronę logowania z komunikatem.
 */
function requireLogin(string $redirectTo = 'login.php'): void
{
    if (empty($_SESSION['user_id'])) {
        $_SESSION['flash_error'] = 'Musisz być zalogowany, aby uzyskać dostęp do tej strony.';
        header('Location: ' . $redirectTo);
        exit;
    }
}

/**
 * Sprawdza czy zalogowany użytkownik ma rolę admina.
 * Jeśli nie – zwraca 403.
 */
function requireAdmin(): void
{
    requireLogin();
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        http_response_code(403);
        die('<h1 style="font-family:sans-serif;color:#d4af37;background:#0d0d0d;padding:40px;">
              403 – Brak uprawnień administratora.
             </h1>');
    }
}

/**
 * Zwraca true jeśli użytkownik jest zalogowany.
 */
function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}

/**
 * Zwraca true jeśli zalogowany użytkownik jest adminem.
 */
function isAdmin(): bool
{
    return isLoggedIn() && ($_SESSION['user_role'] ?? '') === 'admin';
}

/**
 * Pobiera i czyści jednorazowy komunikat (flash message) z sesji.
 */
function getFlash(string $key): string
{
    $msg = $_SESSION[$key] ?? '';
    unset($_SESSION[$key]);
    return $msg;
}

/**
 * Escapuje dane wyjściowe (ochrona XSS).
 */
function e(string $str): string
{
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}