<?php
/**
 * kontakt_action.php
 * Przetwarza formularz kontaktowy i zapisuje wiadomość do bazy danych.
 * Ochrona: CSRF token, Prepared Statements (SQL Injection), htmlspecialchars (XSS).
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Obsługujemy tylko żądania POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php#kontakt');
    exit;
}

// Walidacja CSRF
if (
    empty($_POST['csrf_token']) ||
    !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])
) {
    $_SESSION['contact_error'] = 'Nieprawidłowe żądanie. Odśwież stronę i spróbuj ponownie.';
    header('Location: index.php#kontakt');
    exit;
}

// Zbieramy i czyścimy dane
$name    = trim($_POST['name']    ?? '');
$email   = trim($_POST['email']   ?? '');
$message = trim($_POST['message'] ?? '');

// Walidacja po stronie serwera
$errors = [];

if ($name === '' || mb_strlen($name) < 2) {
    $errors[] = 'Podaj imię i nazwisko (minimum 2 znaki).';
}
if (mb_strlen($name) > 100) {
    $errors[] = 'Imię i nazwisko nie może przekraczać 100 znaków.';
}
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Podaj prawidłowy adres e-mail.';
}
if (mb_strlen($email) > 120) {
    $errors[] = 'Adres e-mail jest zbyt długi.';
}
if ($message === '' || mb_strlen($message) < 10) {
    $errors[] = 'Wiadomość musi zawierać co najmniej 10 znaków.';
}
if (mb_strlen($message) > 2000) {
    $errors[] = 'Wiadomość jest zbyt długa (maksymalnie 2000 znaków).';
}

if (!empty($errors)) {
    $_SESSION['contact_error'] = implode(' ', $errors);
    header('Location: index.php#kontakt');
    exit;
}

// Zapis do bazy danych (Prepared Statement – ochrona przed SQL Injection)
try {
    $stmt = $pdo->prepare(
        'INSERT INTO kontakt (name, email, message) VALUES (:name, :email, :message)'
    );
    $stmt->execute([
        ':name'    => $name,
        ':email'   => $email,
        ':message' => $message,
    ]);

    // Regeneruj token CSRF po udanym zapisie
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    $_SESSION['contact_success'] = 'Twoja wiadomość została wysłana. Odpiszemy w ciągu 24 godzin!';
} catch (PDOException $e) {
    error_log('Błąd zapisu kontaktu: ' . $e->getMessage());
    $_SESSION['contact_error'] = 'Wystąpił błąd serwera. Spróbuj ponownie za chwilę.';
}

header('Location: index.php#kontakt');
exit;