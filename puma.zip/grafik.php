<?php
/**
 * grafik.php – Strona z harmonogramem zajęć (grafik jako zdjęcie).
 */
require_once 'includes/auth.php';
$pageTitle = 'Grafik Zajęć';
require_once 'includes/header.php';
?>

<main>
<section class="grafik-section" aria-labelledby="grafik-title">
    <h2 class="section-title" id="grafik-title">Grafik <span class="gold">Zajęć</span></h2>
    <p style="text-align:center;color:var(--gray);margin-top:-40px;margin-bottom:48px;font-size:16px;">
        Aktualne godziny zajęć grupowych i treningów personalnych.
    </p>

    <div class="grafik-container">
        <img
            src="assets/img/grafik.jpg"
            alt="Harmonogram zajęć siłowni PUMA FLEX – tygodniowy grafik treningów grupowych, klas fitness i zajęć z trenerem"
            loading="lazy"
            style="width:100%;height:auto;display:block;"
        >
    </div>

    <p style="text-align:center;color:var(--gray);font-size:14px;margin-top:24px;">
        Grafik może ulec zmianie. Aktualne informacje uzyskasz telefonicznie lub przez formularz kontaktowy.
    </p>

    <div style="text-align:center;margin-top:40px;">
        <a href="<?= isLoggedIn() ? 'rezerwacja.php' : 'login.php' ?>"
           class="btn btn-primary"
           aria-label="Zarezerwuj swój trening personalny">
            ZAREZERWUJ TRENING
        </a>
    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>