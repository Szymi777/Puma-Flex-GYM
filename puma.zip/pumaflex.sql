-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Maj 17, 2026 at 03:21 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pumaflex`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dostepnosc_trenerow`
--

CREATE TABLE `dostepnosc_trenerow` (
  `id` int(11) NOT NULL,
  `trener_id` int(11) NOT NULL,
  `dzien_tyg` tinyint(1) NOT NULL COMMENT '1=Pon, 2=Wt, 3=Sr, 4=Czw, 5=Pt, 6=Sob, 7=Nd',
  `godzina_od` time NOT NULL,
  `godzina_do` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dostepnosc_trenerow`
--

INSERT INTO `dostepnosc_trenerow` (`id`, `trener_id`, `dzien_tyg`, `godzina_od`, `godzina_do`) VALUES
(1, 1, 1, '08:00:00', '16:00:00'),
(2, 1, 2, '08:00:00', '16:00:00'),
(3, 1, 3, '08:00:00', '16:00:00'),
(4, 1, 4, '08:00:00', '16:00:00'),
(5, 1, 5, '08:00:00', '14:00:00'),
(6, 2, 1, '10:00:00', '18:00:00'),
(7, 2, 2, '10:00:00', '18:00:00'),
(8, 2, 3, '10:00:00', '18:00:00'),
(9, 2, 4, '10:00:00', '18:00:00'),
(10, 2, 5, '10:00:00', '16:00:00'),
(11, 2, 6, '09:00:00', '13:00:00'),
(12, 3, 1, '06:00:00', '14:00:00'),
(13, 3, 2, '06:00:00', '14:00:00'),
(14, 3, 3, '06:00:00', '14:00:00'),
(15, 3, 4, '06:00:00', '14:00:00'),
(16, 3, 5, '06:00:00', '14:00:00'),
(17, 4, 2, '12:00:00', '20:00:00'),
(18, 4, 3, '12:00:00', '20:00:00'),
(19, 4, 4, '12:00:00', '20:00:00'),
(20, 4, 5, '12:00:00', '20:00:00'),
(21, 4, 6, '10:00:00', '16:00:00'),
(22, 5, 1, '14:00:00', '21:00:00'),
(23, 5, 2, '14:00:00', '21:00:00'),
(24, 5, 3, '14:00:00', '21:00:00'),
(25, 5, 4, '14:00:00', '21:00:00'),
(26, 5, 5, '14:00:00', '21:00:00'),
(27, 5, 6, '10:00:00', '18:00:00'),
(28, 6, 1, '09:00:00', '17:00:00'),
(29, 6, 2, '09:00:00', '17:00:00'),
(30, 6, 3, '09:00:00', '17:00:00'),
(31, 6, 4, '09:00:00', '17:00:00'),
(32, 6, 5, '09:00:00', '15:00:00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kontakt`
--

CREATE TABLE `kontakt` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `message` text NOT NULL,
  `przeczytana` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kontakt`
--

INSERT INTO `kontakt` (`id`, `name`, `email`, `message`, `przeczytana`, `created_at`) VALUES
(1, 'Szymon Dziedziński', 'szymon_rz24@wp.pl', 'Kiedy ta zumba?', 0, '2026-05-17 12:58:53');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `id` int(11) NOT NULL,
  `uzytkownik_id` int(11) NOT NULL,
  `trener_id` int(11) NOT NULL,
  `data_treningu` date NOT NULL,
  `godzina_od` time NOT NULL,
  `godzina_do` time NOT NULL,
  `notatka` text DEFAULT NULL,
  `status` enum('oczekujaca','potwierdzona','odwolana') NOT NULL DEFAULT 'oczekujaca',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rezerwacje`
--

INSERT INTO `rezerwacje` (`id`, `uzytkownik_id`, `trener_id`, `data_treningu`, `godzina_od`, `godzina_do`, `notatka`, `status`, `created_at`) VALUES
(1, 2, 2, '2026-06-24', '12:00:00', '13:00:00', 'Spierdalaj', 'odwolana', '2026-05-17 12:33:11');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `trenerzy`
--

CREATE TABLE `trenerzy` (
  `id` int(11) NOT NULL,
  `imie_nazwisko` varchar(100) NOT NULL,
  `specjalizacja` varchar(150) NOT NULL,
  `opis` text NOT NULL,
  `zdjecie` varchar(255) NOT NULL DEFAULT 'assets/img/trener1.jpg',
  `aktywny` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trenerzy`
--

INSERT INTO `trenerzy` (`id`, `imie_nazwisko`, `specjalizacja`, `opis`, `zdjecie`, `aktywny`, `created_at`) VALUES
(1, 'Wojfer 87', 'Trening Siłowy & Sylwetka', '12 lat doświadczenia w przygotowaniu sylwetkowym. Trzykrotny Mistrz Polski w wyciskaniu sztangi na stole. Legenda przysiadów z fotelem, maksymalny ciężar uginania na biceps - kibel + 2 hantle', 'assets/img/trener1.jpg', 1, '2026-05-17 12:18:49'),
(2, 'Patryk Bandurski', 'Dieta', 'Nauczy Cię czym jest prawdziwa masa. Z nim nawpierdalasz się do spodu', 'assets/img/trener2.jpg', 1, '2026-05-17 12:18:49'),
(3, 'Karolinka', 'CrossFit & Wytrzymałość', 'Niewiadomo co tu robi ale jest zajebista. Nie ma co robić psychozy i o to w tym wszystkim chodzi', 'assets/img/trener3.jpg', 1, '2026-05-17 12:18:49'),
(4, 'Dżinolt', 'Fitness & Dietetyka', 'Łysy potrafi zaskoczyć, trening z nim to prawdziwa niespodzianka, a hantle na zdjęciu profilowym skrywają pod sobą więcej niż Ci się wydaje', 'assets/img/trener4.jpg', 1, '2026-05-17 12:18:49'),
(5, 'Gymlajfer', 'Psychomotoryka', 'Mimo że ogranicza cukier, żaden jebaniec z biedronki nie jest mu straszny. Potrafi nauczyć Cię odpowiedniego liczenia kalori, wyboru odpowiednich batonów oraz sekretów herbatki Verdin', 'assets/img/trener5.jpg', 1, '2026-05-17 12:18:49'),
(6, 'Owca WK', 'Pilates & Rehabilitacja', 'Jazda z kurwami. 300 to mit', 'assets/img/trener6.jpg', 1, '2026-05-17 12:18:49');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `uzytkownicy`
--

CREATE TABLE `uzytkownicy` (
  `id` int(11) NOT NULL,
  `imie` varchar(60) NOT NULL DEFAULT '',
  `nazwisko` varchar(60) NOT NULL DEFAULT '',
  `email` varchar(120) NOT NULL,
  `haslo` varchar(255) NOT NULL,
  `rola` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `uzytkownicy`
--

INSERT INTO `uzytkownicy` (`id`, `imie`, `nazwisko`, `email`, `haslo`, `rola`, `created_at`) VALUES
(1, 'Admin', 'PumaFlex', 'admin@pumaflex.pl', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uAnFm/DVO', 'admin', '2026-05-17 12:18:49'),
(2, 'Szymon', 'Dziedziński', 'szymon_rz24@wp.pl', '$2y$10$JkDVcSa12T.cKyErOItEAOsh9T0X8VeCXjrmxzbEbYNFwg35K9JSq', 'user', '2026-05-17 12:32:43'),
(3, 'Szymon', 'Dziedziński', 'szymon@pumaflex.pl', '$2y$10$n.pn0alIOgyZKKxzlPuzNuHzfXP1qL4BQVMvXJl4/oxQoZl7bIqyy', 'admin', '2026-05-17 13:13:55');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dostepnosc_trenerow`
--
ALTER TABLE `dostepnosc_trenerow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trener_id` (`trener_id`);

--
-- Indeksy dla tabeli `kontakt`
--
ALTER TABLE `kontakt`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uzytkownik_id` (`uzytkownik_id`),
  ADD KEY `trener_id` (`trener_id`);

--
-- Indeksy dla tabeli `trenerzy`
--
ALTER TABLE `trenerzy`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dostepnosc_trenerow`
--
ALTER TABLE `dostepnosc_trenerow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `kontakt`
--
ALTER TABLE `kontakt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rezerwacje`
--
ALTER TABLE `rezerwacje`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trenerzy`
--
ALTER TABLE `trenerzy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `uzytkownicy`
--
ALTER TABLE `uzytkownicy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dostepnosc_trenerow`
--
ALTER TABLE `dostepnosc_trenerow`
  ADD CONSTRAINT `fk_dostepnosc_trener` FOREIGN KEY (`trener_id`) REFERENCES `trenerzy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD CONSTRAINT `fk_rez_trener` FOREIGN KEY (`trener_id`) REFERENCES `trenerzy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rez_uzytkownik` FOREIGN KEY (`uzytkownik_id`) REFERENCES `uzytkownicy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
