<?php
/**
 * admin/index.php – Panel główny administratora (Dashboard).
 * Wyświetla statystyki serwisu.
 */
require_once 'auth_guard.php';

$pageTitle = 'Panel Administratora';

// Statystyki
$stats = [
    'uzytkownicy'  => $pdo->query('SELECT COUNT(*) FROM uzytkownicy')->fetchColumn(),
    'trenerzy'     => $pdo->query('SELECT COUNT(*) FROM trenerzy WHERE aktywny = 1')->fetchColumn(),
    'rezerwacje'   => $pdo->query('SELECT COUNT(*) FROM rezerwacje')->fetchColumn(),
    'wiadomosci'   => $pdo->query('SELECT COUNT(*) FROM kontakt WHERE przeczytana = 0')->fetchColumn(),
];

// Ostatnie 5 rezerwacji
$lastRez = $pdo->query(
    'SELECT r.id, r.data_treningu, r.godzina_od, r.status,
            u.imie, u.nazwisko, u.email,
            t.imie_nazwisko AS trener_name
       FROM rezerwacje r
       JOIN uzytkownicy u ON u.id = r.uzytkownik_id
       JOIN trenerzy    t ON t.id = r.trener_id
      ORDER BY r.created_at DESC
      LIMIT 5'
)->fetchAll();

// Ostatnie 5 wiadomości
$lastMsg = $pdo->query(
    'SELECT id, name, email, LEFT(message, 80) AS msg_short, przeczytana, created_at
       FROM kontakt
      ORDER BY created_at DESC
      LIMIT 5'
)->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

// Dołącz header (z katalogu nadrzędnego)
require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="admin-layout">
    <!-- Sidebar -->
    <?php require_once 'sidebar.php'; ?>

    <!-- Treść -->
    <main class="admin-main" id="admin-content">
        <div class="admin-header">
            <h1>Dashboard</h1>
            <p style="color:var(--gray);font-size:14px;">
                Witaj, <strong style="color:var(--gold);"><?= e($_SESSION['user_name']) ?></strong>
                · <?= date('d.m.Y, H:i') ?>
            </p>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-error" role="alert"><?= e($flashError) ?></div>
        <?php endif; ?>

        <!-- Statystyki -->
        <div class="stats-grid" aria-label="Statystyki serwisu">
            <div class="stat-card">
                <div class="stat-number"><?= (int)$stats['uzytkownicy'] ?></div>
                <div class="stat-label">Użytkownicy</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= (int)$stats['trenerzy'] ?></div>
                <div class="stat-label">Aktywni Trenerzy</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= (int)$stats['rezerwacje'] ?></div>
                <div class="stat-label">Rezerwacje</div>
            </div>
            <div class="stat-card">
                <div class="stat-number" style="color:<?= $stats['wiadomosci'] > 0 ? 'var(--red-error)' : 'var(--gold)' ?>">
                    <?= (int)$stats['wiadomosci'] ?>
                </div>
                <div class="stat-label">Nowe Wiadomości</div>
            </div>
        </div>

        <!-- Ostatnie rezerwacje -->
        <h3 style="color:var(--gold);margin-bottom:16px;font-size:18px;">Ostatnie Rezerwacje</h3>
        <div class="admin-table-wrapper" style="margin-bottom:40px;">
            <table class="admin-table" aria-label="Tabela ostatnich rezerwacji">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Użytkownik</th>
                        <th scope="col">Trener</th>
                        <th scope="col">Data</th>
                        <th scope="col">Godzina</th>
                        <th scope="col">Status</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($lastRez)): ?>
                        <tr><td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">Brak rezerwacji.</td></tr>
                    <?php else: ?>
                        <?php foreach ($lastRez as $r): ?>
                            <tr>
                                <td>#<?= (int)$r['id'] ?></td>
                                <td><?= e($r['imie'] . ' ' . $r['nazwisko']) ?><br>
                                    <small style="color:var(--gray);"><?= e($r['email']) ?></small>
                                </td>
                                <td><?= e($r['trener_name']) ?></td>
                                <td><?= date('d.m.Y', strtotime($r['data_treningu'])) ?></td>
                                <td><?= substr($r['godzina_od'],0,5) ?></td>
                                <td>
                                    <span class="status-badge status-<?= e($r['status']) ?>">
                                        <?= ucfirst(e($r['status'])) ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="reservations.php?edit=<?= (int)$r['id'] ?>"
                                       class="btn btn-primary btn-sm"
                                       aria-label="Edytuj rezerwację #<?= (int)$r['id'] ?>">
                                        Edytuj
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Ostatnie wiadomości -->
        <h3 style="color:var(--gold);margin-bottom:16px;font-size:18px;">Ostatnie Wiadomości Kontaktowe</h3>
        <div class="admin-table-wrapper">
            <table class="admin-table" aria-label="Tabela ostatnich wiadomości kontaktowych">
                <thead>
                    <tr>
                        <th scope="col">Nadawca</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Fragment wiadomości</th>
                        <th scope="col">Data</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($lastMsg)): ?>
                        <tr><td colspan="5" style="text-align:center;color:var(--gray);padding:30px;">Brak wiadomości.</td></tr>
                    <?php else: ?>
                        <?php foreach ($lastMsg as $m): ?>
                            <tr style="<?= $m['przeczytana'] ? '' : 'font-weight:600;' ?>">
                                <td><?= e($m['name']) ?></td>
                                <td><?= e($m['email']) ?></td>
                                <td><?= e($m['msg_short']) ?>...</td>
                                <td><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></td>
                                <td>
                                    <a href="messages.php?id=<?= (int)$m['id'] ?>"
                                       class="btn btn-primary btn-sm"
                                       aria-label="Czytaj wiadomość od <?= e($m['name']) ?>">
                                        Czytaj
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>