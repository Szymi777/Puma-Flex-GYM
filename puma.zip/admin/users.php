<?php
/**
 * admin/users.php – CRUD użytkowników.
 * Create: formularz dodawania
 * Read:   tabela z listą
 * Update: edycja danych i roli
 * Delete: usuwanie (z ochroną przed usunięciem własnego konta)
 */
require_once 'auth_guard.php';

$pageTitle = 'Zarządzanie Użytkownikami';
$errors    = [];
$editUser  = null;

// ----------------------------------------------------------------
// DELETE użytkownika
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token CSRF.';
        header('Location: users.php'); exit;
    }
    $delId = (int)($_POST['user_id'] ?? 0);
    if ($delId === (int)$_SESSION['user_id']) {
        $_SESSION['flash_error'] = 'Nie możesz usunąć własnego konta administratora.';
    } else {
        $del = $pdo->prepare('DELETE FROM uzytkownicy WHERE id = :id');
        $del->execute([':id' => $delId]);
        $_SESSION['flash_success'] = 'Użytkownik został usunięty.';
    }
    header('Location: users.php'); exit;
}

// ----------------------------------------------------------------
// UPDATE użytkownika
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token CSRF.';
        header('Location: users.php'); exit;
    }
    $updId     = (int)($_POST['user_id']  ?? 0);
    $updImie   = trim($_POST['imie']      ?? '');
    $updNazw   = trim($_POST['nazwisko']  ?? '');
    $updEmail  = trim($_POST['email']     ?? '');
    $updRola   = in_array($_POST['rola'] ?? '', ['user','admin']) ? $_POST['rola'] : 'user';
    $updHaslo  = $_POST['haslo'] ?? '';

    if (mb_strlen($updImie) < 2)                         { $errors[] = 'Imię – min. 2 znaki.'; }
    if (mb_strlen($updNazw) < 2)                         { $errors[] = 'Nazwisko – min. 2 znaki.'; }
    if (!filter_var($updEmail, FILTER_VALIDATE_EMAIL))   { $errors[] = 'Nieprawidłowy e-mail.'; }
    if ($updHaslo !== '' && mb_strlen($updHaslo) < 8)   { $errors[] = 'Nowe hasło – min. 8 znaków.'; }

    // Sprawdź duplikat e-maila (poza edytowanym użytkownikiem)
    if (empty($errors)) {
        $chk = $pdo->prepare('SELECT id FROM uzytkownicy WHERE email = :email AND id != :id');
        $chk->execute([':email' => $updEmail, ':id' => $updId]);
        if ($chk->fetch()) { $errors[] = 'Ten adres e-mail jest już zajęty.'; }
    }

    if (empty($errors)) {
        if ($updHaslo !== '') {
            $hash = password_hash($updHaslo, PASSWORD_DEFAULT);
            $upd = $pdo->prepare(
                'UPDATE uzytkownicy SET imie=:imie, nazwisko=:nazw, email=:email, rola=:rola, haslo=:haslo
                  WHERE id=:id'
            );
            $upd->execute([':imie'=>$updImie,':nazw'=>$updNazw,':email'=>$updEmail,':rola'=>$updRola,':haslo'=>$hash,':id'=>$updId]);
        } else {
            $upd = $pdo->prepare(
                'UPDATE uzytkownicy SET imie=:imie, nazwisko=:nazw, email=:email, rola=:rola WHERE id=:id'
            );
            $upd->execute([':imie'=>$updImie,':nazw'=>$updNazw,':email'=>$updEmail,':rola'=>$updRola,':id'=>$updId]);
        }
        $_SESSION['flash_success'] = 'Dane użytkownika zostały zaktualizowane.';
        header('Location: users.php'); exit;
    } else {
        // Przywróć dane do formularza edycji
        $editUser = ['id'=>$updId,'imie'=>$updImie,'nazwisko'=>$updNazw,'email'=>$updEmail,'rola'=>$updRola];
    }
}

// ----------------------------------------------------------------
// CREATE użytkownika
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token CSRF.';
        header('Location: users.php'); exit;
    }
    $newImie  = trim($_POST['new_imie']    ?? '');
    $newNazw  = trim($_POST['new_nazwisko']?? '');
    $newEmail = trim($_POST['new_email']   ?? '');
    $newHaslo = $_POST['new_haslo']        ?? '';
    $newRola  = in_array($_POST['new_rola']??'', ['user','admin']) ? $_POST['new_rola'] : 'user';

    if (mb_strlen($newImie) < 2)                        { $errors[] = 'Imię – min. 2 znaki.'; }
    if (mb_strlen($newNazw) < 2)                        { $errors[] = 'Nazwisko – min. 2 znaki.'; }
    if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL))  { $errors[] = 'Nieprawidłowy e-mail.'; }
    if (mb_strlen($newHaslo) < 8)                       { $errors[] = 'Hasło – min. 8 znaków.'; }

    if (empty($errors)) {
        $chk = $pdo->prepare('SELECT id FROM uzytkownicy WHERE email = :email');
        $chk->execute([':email' => $newEmail]);
        if ($chk->fetch()) { $errors[] = 'Ten e-mail jest już zajęty.'; }
    }
    if (empty($errors)) {
        $hash = password_hash($newHaslo, PASSWORD_DEFAULT);
        $ins = $pdo->prepare(
            'INSERT INTO uzytkownicy (imie, nazwisko, email, haslo, rola) VALUES (:i,:n,:e,:h,:r)'
        );
        $ins->execute([':i'=>$newImie,':n'=>$newNazw,':e'=>$newEmail,':h'=>$hash,':r'=>$newRola]);
        $_SESSION['flash_success'] = 'Użytkownik ' . $newImie . ' ' . $newNazw . ' został dodany.';
        header('Location: users.php'); exit;
    }
}

// ----------------------------------------------------------------
// READ – pobierz edytowanego (z GET)
// ----------------------------------------------------------------
if (isset($_GET['edit'])) {
    $stmtE = $pdo->prepare('SELECT id, imie, nazwisko, email, rola FROM uzytkownicy WHERE id = :id');
    $stmtE->execute([':id' => (int)$_GET['edit']]);
    $editUser = $stmtE->fetch() ?: null;
}

// Pobierz wszystkich użytkowników
$users = $pdo->query(
    'SELECT id, imie, nazwisko, email, rola, created_at FROM uzytkownicy ORDER BY created_at DESC'
)->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="admin-layout">
    <?php require_once 'sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1>Użytkownicy</h1>
            <span style="color:var(--gray);font-size:14px;"><?= count($users) ?> kont w bazie</span>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-error" role="alert"><?= e($flashError) ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error" role="alert">
                <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Formularz dodawania użytkownika -->
        <details style="margin-bottom:32px;">
            <summary style="cursor:pointer;color:var(--gold);font-weight:700;font-size:16px;margin-bottom:16px;list-style:none;">
                ➕ Dodaj nowego użytkownika
            </summary>
            <div class="admin-form" style="margin-top:20px;">
                <form method="POST" action="users.php" aria-label="Formularz dodawania nowego użytkownika">
                    <input type="hidden" name="action"     value="create">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <div class="admin-form-grid">
                        <div class="form-group">
                            <label for="new-imie">Imię</label>
                            <input type="text" id="new-imie" name="new_imie" required maxlength="60"
                                   value="<?= e($_POST['new_imie'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="new-nazwisko">Nazwisko</label>
                            <input type="text" id="new-nazwisko" name="new_nazwisko" required maxlength="60"
                                   value="<?= e($_POST['new_nazwisko'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="new-email">E-mail</label>
                            <input type="email" id="new-email" name="new_email" required maxlength="120"
                                   value="<?= e($_POST['new_email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="new-haslo">Hasło (min. 8 znaków)</label>
                            <input type="password" id="new-haslo" name="new_haslo" required minlength="8">
                        </div>
                        <div class="form-group">
                            <label for="new-rola">Rola</label>
                            <select id="new-rola" name="new_rola">
                                <option value="user">Użytkownik</option>
                                <option value="admin">Administrator</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" aria-label="Utwórz nowe konto użytkownika">
                        UTWÓRZ KONTO
                    </button>
                </form>
            </div>
        </details>

        <!-- Formularz edycji (widoczny gdy $editUser !== null) -->
        <?php if ($editUser): ?>
            <div class="admin-form" style="margin-bottom:32px;border-color:var(--gold);">
                <h3 style="color:var(--gold);margin-bottom:24px;">
                    ✏️ Edycja użytkownika #<?= (int)$editUser['id'] ?>
                </h3>
                <form method="POST" action="users.php" aria-label="Formularz edycji użytkownika">
                    <input type="hidden" name="action"     value="update">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="user_id"    value="<?= (int)$editUser['id'] ?>">
                    <div class="admin-form-grid">
                        <div class="form-group">
                            <label for="edit-imie">Imię</label>
                            <input type="text" id="edit-imie" name="imie" required
                                   value="<?= e($editUser['imie']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit-nazwisko">Nazwisko</label>
                            <input type="text" id="edit-nazwisko" name="nazwisko" required
                                   value="<?= e($editUser['nazwisko']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit-email">E-mail</label>
                            <input type="email" id="edit-email" name="email" required
                                   value="<?= e($editUser['email']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit-haslo">Nowe hasło (zostaw puste = bez zmian)</label>
                            <input type="password" id="edit-haslo" name="haslo" minlength="8" autocomplete="new-password">
                        </div>
                        <div class="form-group">
                            <label for="edit-rola">Rola</label>
                            <select id="edit-rola" name="rola">
                                <option value="user"  <?= $editUser['rola']==='user'  ? 'selected' : '' ?>>Użytkownik</option>
                                <option value="admin" <?= $editUser['rola']==='admin' ? 'selected' : '' ?>>Administrator</option>
                            </select>
                        </div>
                    </div>
                    <div style="display:flex;gap:12px;flex-wrap:wrap;">
                        <button type="submit" class="btn btn-primary" aria-label="Zapisz zmiany użytkownika">
                            ZAPISZ ZMIANY
                        </button>
                        <a href="users.php" class="btn btn-secondary" aria-label="Anuluj edycję">ANULUJ</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <!-- Tabela użytkowników -->
        <div class="admin-table-wrapper">
            <table class="admin-table" aria-label="Lista wszystkich użytkowników PUMA FLEX">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Imię i Nazwisko</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Rola</th>
                        <th scope="col">Data rejestracji</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">
                                Brak użytkowników.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $u): ?>
                            <tr>
                                <td>#<?= (int)$u['id'] ?></td>
                                <td><?= e($u['imie'] . ' ' . $u['nazwisko']) ?></td>
                                <td><?= e($u['email']) ?></td>
                                <td>
                                    <span class="status-badge <?= $u['rola']==='admin' ? 'status-potwierdzona' : 'status-oczekujaca' ?>">
                                        <?= $u['rola']==='admin' ? '👑 Admin' : '👤 User' ?>
                                    </span>
                                </td>
                                <td><?= date('d.m.Y', strtotime($u['created_at'])) ?></td>
                                <td>
                                    <div class="admin-actions">
                                        <a href="users.php?edit=<?= (int)$u['id'] ?>"
                                           class="btn btn-primary btn-sm"
                                           aria-label="Edytuj użytkownika <?= e($u['imie'] . ' ' . $u['nazwisko']) ?>">
                                            Edytuj
                                        </a>
                                        <?php if ((int)$u['id'] !== (int)$_SESSION['user_id']): ?>
                                            <form method="POST" action="users.php" style="display:inline;"
                                                  onsubmit="return confirm('Czy na pewno chcesz usunąć użytkownika <?= e($u['imie']) ?>?')">
                                                <input type="hidden" name="action"     value="delete">
                                                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                                <input type="hidden" name="user_id"    value="<?= (int)$u['id'] ?>">
                                                <button type="submit" class="btn btn-danger btn-sm"
                                                        aria-label="Usuń użytkownika <?= e($u['imie'] . ' ' . $u['nazwisko']) ?>">
                                                    Usuń
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span style="font-size:12px;color:var(--gray);">(Twoje konto)</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>