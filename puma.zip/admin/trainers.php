<?php
/**
 * admin/trainers.php – CRUD trenerów.
 */
require_once 'auth_guard.php';

$pageTitle = 'Zarządzanie Trenerami';
$errors    = [];
$editT     = null;

// ----------------------------------------------------------------
// DELETE -- Tutaj coś jest rozjebane to do sprawdzenia
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: trainers.php'); exit;
    }
    $del = $pdo->prepare('DELETE FROM trenerzy WHERE id = :id');
    $del->execute([':id' => (int)$_POST['trainer_id']]);
    $_SESSION['flash_success'] = 'Trener usunięty z bazy.';
    header('Location: trainers.php'); exit;
}

// ----------------------------------------------------------------
// CREATE
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: trainers.php'); exit;
    }
    $imieNaz  = trim($_POST['imie_nazwisko'] ?? '');
    $spec     = trim($_POST['specjalizacja'] ?? '');
    $opis     = trim($_POST['opis']          ?? '');
    $zdjecie  = trim($_POST['zdjecie']       ?? 'assets/img/trener1.jpg');
    $aktywny  = isset($_POST['aktywny']) ? 1 : 0;

    if (mb_strlen($imieNaz) < 3) { $errors[] = 'Podaj imię i nazwisko trenera.'; }
    if (mb_strlen($spec) < 3)    { $errors[] = 'Podaj specjalizację.'; }
    if (mb_strlen($opis) < 10)   { $errors[] = 'Opis musi mieć min. 10 znaków.'; }

    if (empty($errors)) {
        $ins = $pdo->prepare(
            'INSERT INTO trenerzy (imie_nazwisko, specjalizacja, opis, zdjecie, aktywny) VALUES (:i,:s,:o,:z,:a)'
        );
        $ins->execute([':i'=>$imieNaz,':s'=>$spec,':o'=>$opis,':z'=>$zdjecie,':a'=>$aktywny]);
        $_SESSION['flash_success'] = 'Trener ' . $imieNaz . ' został dodany.';
        header('Location: trainers.php'); exit;
    }
}

// ----------------------------------------------------------------
// UPDATE
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: trainers.php'); exit;
    }
    $tId     = (int)$_POST['trainer_id'];
    $imieNaz = trim($_POST['imie_nazwisko'] ?? '');
    $spec    = trim($_POST['specjalizacja'] ?? '');
    $opis    = trim($_POST['opis']          ?? '');
    $zdjecie = trim($_POST['zdjecie']       ?? '');
    $aktywny = isset($_POST['aktywny']) ? 1 : 0;

    if (mb_strlen($imieNaz) < 3) { $errors[] = 'Podaj imię i nazwisko trenera.'; }
    if (mb_strlen($spec) < 3)    { $errors[] = 'Podaj specjalizację.'; }
    if (mb_strlen($opis) < 10)   { $errors[] = 'Opis musi mieć min. 10 znaków.'; }

    if (empty($errors)) {
        $upd = $pdo->prepare(
            'UPDATE trenerzy SET imie_nazwisko=:i, specjalizacja=:s, opis=:o, zdjecie=:z, aktywny=:a WHERE id=:id'
        );
        $upd->execute([':i'=>$imieNaz,':s'=>$spec,':o'=>$opis,':z'=>$zdjecie,':a'=>$aktywny,':id'=>$tId]);
        $_SESSION['flash_success'] = 'Dane trenera zostały zaktualizowane.';
        header('Location: trainers.php'); exit;
    } else {
        $editT = ['id'=>$tId,'imie_nazwisko'=>$imieNaz,'specjalizacja'=>$spec,'opis'=>$opis,'zdjecie'=>$zdjecie,'aktywny'=>$aktywny];
    }
}

// READ edycji z GET
if (isset($_GET['edit'])) {
    $stmtE = $pdo->prepare('SELECT * FROM trenerzy WHERE id = :id');
    $stmtE->execute([':id' => (int)$_GET['edit']]);
    $editT = $stmtE->fetch() ?: null;
}

// Pobierz wszystkich trenerów
$trenerzy = $pdo->query(
    'SELECT id, imie_nazwisko, specjalizacja, zdjecie, aktywny, created_at FROM trenerzy ORDER BY id ASC'
)->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="admin-layout">
    <?php require_once 'sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1>Trenerzy</h1>
            <span style="color:var(--gray);font-size:14px;"><?= count($trenerzy) ?> trenerów w bazie</span>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-error" role="alert"><?= e($flashError) ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error" role="alert">
                <?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Dodawanie trenera -->
        <details style="margin-bottom:32px;" <?= !empty($errors) && empty($editT) ? 'open' : '' ?>>
            <summary style="cursor:pointer;color:var(--gold);font-weight:700;font-size:16px;margin-bottom:16px;list-style:none;">
                ➕ Dodaj nowego trenera
            </summary>
            <div class="admin-form" style="margin-top:20px;">
                <form method="POST" action="trainers.php" aria-label="Formularz dodawania nowego trenera">
                    <input type="hidden" name="action"     value="create">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <div class="admin-form-grid">
                        <div class="form-group">
                            <label for="new-imie-naz">Imię i Nazwisko</label>
                            <input type="text" id="new-imie-naz" name="imie_nazwisko" required maxlength="100"
                                   value="<?= e($_POST['imie_nazwisko'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="new-spec">Specjalizacja</label>
                            <input type="text" id="new-spec" name="specjalizacja" required maxlength="150"
                                   value="<?= e($_POST['specjalizacja'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="new-opis">Opis / Biografia</label>
                        <textarea id="new-opis" name="opis" rows="4" required maxlength="1000"><?= e($_POST['opis'] ?? '') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="new-zdjecie">
                            Ścieżka do zdjęcia
                            <small style="color:var(--gray);font-weight:400;">(np. assets/img/trener7.jpg)</small>
                        </label>
                        <input type="text" id="new-zdjecie" name="zdjecie" maxlength="255"
                               placeholder="assets/img/trener7.jpg"
                               value="<?= e($_POST['zdjecie'] ?? '') ?>">
                    </div>
                    <div class="form-group" style="flex-direction:row;align-items:center;gap:12px;">
                        <input type="checkbox" id="new-aktywny" name="aktywny" value="1" checked style="width:auto;">
                        <label for="new-aktywny" style="text-transform:none;font-size:15px;">Aktywny (widoczny na stronie)</label>
                    </div>
                    <button type="submit" class="btn btn-primary" aria-label="Dodaj nowego trenera do systemu">
                        DODAJ TRENERA
                    </button>
                </form>
            </div>
        </details>

        <!-- Edycja trenera -->
        <?php if ($editT): ?>
            <div class="admin-form" style="margin-bottom:32px;border-color:var(--gold);">
                <h3 style="color:var(--gold);margin-bottom:24px;">
                    ✏️ Edycja trenera: <?= e($editT['imie_nazwisko']) ?>
                </h3>
                <form method="POST" action="trainers.php" aria-label="Formularz edycji danych trenera">
                    <input type="hidden" name="action"     value="update">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="trainer_id" value="<?= (int)$editT['id'] ?>">
                    <div class="admin-form-grid">
                        <div class="form-group">
                            <label for="edit-imie-naz">Imię i Nazwisko</label>
                            <input type="text" id="edit-imie-naz" name="imie_nazwisko" required
                                   value="<?= e($editT['imie_nazwisko']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="edit-spec">Specjalizacja</label>
                            <input type="text" id="edit-spec" name="specjalizacja" required
                                   value="<?= e($editT['specjalizacja']) ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="edit-opis">Opis / Biografia</label>
                        <textarea id="edit-opis" name="opis" rows="4" required><?= e($editT['opis']) ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit-zdjecie">Ścieżka do zdjęcia</label>
                        <input type="text" id="edit-zdjecie" name="zdjecie" value="<?= e($editT['zdjecie']) ?>">
                    </div>
                    <div class="form-group" style="flex-direction:row;align-items:center;gap:12px;">
                        <input type="checkbox" id="edit-aktywny" name="aktywny" value="1"
                               style="width:auto;" <?= $editT['aktywny'] ? 'checked' : '' ?>>
                        <label for="edit-aktywny" style="text-transform:none;font-size:15px;">Aktywny</label>
                    </div>
                    <div style="display:flex;gap:12px;">
                        <button type="submit" class="btn btn-primary">ZAPISZ ZMIANY</button>
                        <a href="trainers.php" class="btn btn-secondary">ANULUJ</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <!-- Tabela trenerów -->
        <div class="admin-table-wrapper">
            <table class="admin-table" aria-label="Lista wszystkich trenerów PUMA FLEX">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Zdjęcie</th>
                        <th scope="col">Imię i Nazwisko</th>
                        <th scope="col">Specjalizacja</th>
                        <th scope="col">Status</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($trenerzy)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">Brak trenerów.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($trenerzy as $t): ?>
                            <tr>
                                <td>#<?= (int)$t['id'] ?></td>
                                <td>
                                    <img src="../<?= e($t['zdjecie']) ?>"
                                         alt="Miniaturka zdjęcia trenera <?= e($t['imie_nazwisko']) ?>"
                                         style="width:48px;height:48px;object-fit:cover;border-radius:50%;border:2px solid var(--gold);"
                                         onerror="this.style.display='none'">
                                </td>
                                <td><?= e($t['imie_nazwisko']) ?></td>
                                <td><?= e($t['specjalizacja']) ?></td>
                                <td>
                                    <span class="status-badge <?= $t['aktywny'] ? 'status-potwierdzona' : 'status-odwolana' ?>">
                                        <?= $t['aktywny'] ? 'Aktywny' : 'Nieaktywny' ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="admin-actions">
                                        <a href="trainers.php?edit=<?= (int)$t['id'] ?>"
                                           class="btn btn-primary btn-sm"
                                           aria-label="Edytuj dane trenera <?= e($t['imie_nazwisko']) ?>">
                                            Edytuj
                                        </a>
                                        <form method="POST" action="trainers.php" style="display:inline;"
                                              onsubmit="return confirm('Czy na pewno usunąć trenera <?= e($t['imie_nazwisko']) ?>? Usunięcie skasuje też rezerwacje!')">
                                            <input type="hidden" name="action"     value="delete">
                                            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                            <input type="hidden" name="trainer_id" value="<?= (int)$t['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                    aria-label="Usuń trenera <?= e($t['imie_nazwisko']) ?> z bazy">
                                                Usuń
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>