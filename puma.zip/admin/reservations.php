<?php
/**
 * admin/reservations.php – Zarządzanie rezerwacjami.
 * Admin może zmieniać status, edytować i usuwać wszystkie rezerwacje.
 */
require_once 'auth_guard.php';

$pageTitle = 'Zarządzanie Rezerwacjami';
$errors    = [];
$editRez   = null;

// ----------------------------------------------------------------
// DELETE rezerwacji -- Też się coś rozjebało ale działa
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: reservations.php'); exit;
    }
    $del = $pdo->prepare('DELETE FROM rezerwacje WHERE id = :id');
    $del->execute([':id' => (int)$_POST['rez_id']]);
    $_SESSION['flash_success'] = 'Rezerwacja usunięta.';
    header('Location: reservations.php'); exit;
}

// ----------------------------------------------------------------
// UPDATE statusu / danych rezerwacji
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: reservations.php'); exit;
    }
    $rezId  = (int)$_POST['rez_id'];
    $status = in_array($_POST['status']??'', ['oczekujaca','potwierdzona','odwolana'])
              ? $_POST['status'] : 'oczekujaca';
    $notatka = trim($_POST['notatka'] ?? '');

    $upd = $pdo->prepare(
        'UPDATE rezerwacje SET status=:status, notatka=:notatka WHERE id=:id'
    );
    $upd->execute([':status'=>$status,':notatka'=>$notatka,':id'=>$rezId]);
    $_SESSION['flash_success'] = 'Rezerwacja #' . $rezId . ' zaktualizowana.';
    header('Location: reservations.php'); exit;
}

// READ edycji z GET
if (isset($_GET['edit'])) {
    $stmtE = $pdo->prepare(
        'SELECT r.*, u.imie, u.nazwisko, u.email, t.imie_nazwisko AS trener_name
           FROM rezerwacje r
           JOIN uzytkownicy u ON u.id = r.uzytkownik_id
           JOIN trenerzy    t ON t.id = r.trener_id
          WHERE r.id = :id'
    );
    $stmtE->execute([':id' => (int)$_GET['edit']]);
    $editRez = $stmtE->fetch() ?: null;
}

// Filtrowanie po statusie
$filterStatus = $_GET['status'] ?? '';
$validStatuses = ['','oczekujaca','potwierdzona','odwolana'];
if (!in_array($filterStatus, $validStatuses)) { $filterStatus = ''; }

$sql = 'SELECT r.id, r.data_treningu, r.godzina_od, r.godzina_do, r.status, r.created_at,
               u.imie, u.nazwisko, u.email,
               t.imie_nazwisko AS trener_name
          FROM rezerwacje r
          JOIN uzytkownicy u ON u.id = r.uzytkownik_id
          JOIN trenerzy    t ON t.id = r.trener_id';
$params = [];
if ($filterStatus !== '') {
    $sql .= ' WHERE r.status = :status';
    $params[':status'] = $filterStatus;
}
$sql .= ' ORDER BY r.data_treningu DESC, r.godzina_od DESC';

$stmtR = $pdo->prepare($sql);
$stmtR->execute($params);
$rezerwacje = $stmtR->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="admin-layout">
    <?php require_once 'sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1>Rezerwacje</h1>
            <span style="color:var(--gray);font-size:14px;"><?= count($rezerwacje) ?> wyników</span>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
        <?php endif; ?>
        <?php if ($flashError): ?>
            <div class="alert alert-error" role="alert"><?= e($flashError) ?></div>
        <?php endif; ?>

        <!-- Filtry -->
        <form method="GET" action="reservations.php" style="margin-bottom:24px;display:flex;gap:12px;flex-wrap:wrap;"
              aria-label="Filtrowanie rezerwacji po statusie">
            <div class="form-group" style="margin-bottom:0;min-width:200px;">
                <label for="filter-status" style="margin-bottom:4px;">Filtruj po statusie</label>
                <select id="filter-status" name="status" onchange="this.form.submit()"
                        aria-label="Wybierz status rezerwacji do filtrowania">
                    <option value="" <?= $filterStatus==='' ? 'selected' : '' ?>>Wszystkie</option>
                    <option value="oczekujaca"   <?= $filterStatus==='oczekujaca'   ? 'selected' : '' ?>>Oczekujące</option>
                    <option value="potwierdzona" <?= $filterStatus==='potwierdzona' ? 'selected' : '' ?>>Potwierdzone</option>
                    <option value="odwolana"     <?= $filterStatus==='odwolana'     ? 'selected' : '' ?>>Odwołane</option>
                </select>
            </div>
        </form>

        <!-- Formularz edycji rezerwacji -->
        <?php if ($editRez): ?>
            <div class="admin-form" style="margin-bottom:32px;border-color:var(--gold);">
                <h3 style="color:var(--gold);margin-bottom:24px;">
                    ✏️ Edycja rezerwacji #<?= (int)$editRez['id'] ?>
                    – <?= e($editRez['imie'] . ' ' . $editRez['nazwisko']) ?>
                    z <?= e($editRez['trener_name']) ?>
                </h3>
                <form method="POST" action="reservations.php" aria-label="Formularz edycji statusu rezerwacji">
                    <input type="hidden" name="action"     value="update">
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="rez_id"     value="<?= (int)$editRez['id'] ?>">

                    <div class="admin-form-grid">
                        <div class="form-group">
                            <label>Data treningu</label>
                            <input type="text" value="<?= date('d.m.Y', strtotime($editRez['data_treningu'])) ?>" disabled
                                   style="opacity:0.6;cursor:not-allowed;">
                        </div>
                        <div class="form-group">
                            <label>Godzina</label>
                            <input type="text"
                                   value="<?= substr($editRez['godzina_od'],0,5) ?>–<?= substr($editRez['godzina_do'],0,5) ?>"
                                   disabled style="opacity:0.6;cursor:not-allowed;">
                        </div>
                        <div class="form-group">
                            <label for="edit-status">Status rezerwacji</label>
                            <select id="edit-status" name="status" aria-label="Zmień status rezerwacji">
                                <option value="oczekujaca"   <?= $editRez['status']==='oczekujaca'   ? 'selected':'' ?>>Oczekująca</option>
                                <option value="potwierdzona" <?= $editRez['status']==='potwierdzona' ? 'selected':'' ?>>Potwierdzona</option>
                                <option value="odwolana"     <?= $editRez['status']==='odwolana'     ? 'selected':'' ?>>Odwołana</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="edit-notatka-rez">Notatka</label>
                        <textarea id="edit-notatka-rez" name="notatka" rows="3"><?= e($editRez['notatka'] ?? '') ?></textarea>
                    </div>
                    <div style="display:flex;gap:12px;">
                        <button type="submit" class="btn btn-primary">ZAPISZ ZMIANY</button>
                        <a href="reservations.php" class="btn btn-secondary">ANULUJ</a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <!-- Tabela rezerwacji -->
        <div class="admin-table-wrapper">
            <table class="admin-table" aria-label="Tabela wszystkich rezerwacji treningów">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Użytkownik</th>
                        <th scope="col">Trener</th>
                        <th scope="col">Data</th>
                        <th scope="col">Godzina</th>
                        <th scope="col">Status</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rezerwacje)): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;color:var(--gray);padding:30px;">
                                Brak rezerwacji<?= $filterStatus ? ' o statusie "' . e($filterStatus) . '"' : '' ?>.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($rezerwacje as $r): ?>
                            <tr>
                                <td>#<?= (int)$r['id'] ?></td>
                                <td>
                                    <?= e($r['imie'] . ' ' . $r['nazwisko']) ?>
                                    <br><small style="color:var(--gray);"><?= e($r['email']) ?></small>
                                </td>
                                <td><?= e($r['trener_name']) ?></td>
                                <td><?= date('d.m.Y', strtotime($r['data_treningu'])) ?></td>
                                <td><?= substr($r['godzina_od'],0,5) ?>–<?= substr($r['godzina_do'],0,5) ?></td>
                                <td>
                                    <span class="status-badge status-<?= e($r['status']) ?>">
                                        <?= ucfirst(e($r['status'])) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="admin-actions">
                                        <a href="reservations.php?edit=<?= (int)$r['id'] ?>"
                                           class="btn btn-primary btn-sm"
                                           aria-label="Edytuj rezerwację #<?= (int)$r['id'] ?>">
                                            Edytuj
                                        </a>
                                        <form method="POST" action="reservations.php" style="display:inline;"
                                              onsubmit="return confirm('Usunąć rezerwację #<?= (int)$r['id'] ?> na stałe?')">
                                            <input type="hidden" name="action"     value="delete">
                                            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                            <input type="hidden" name="rez_id"     value="<?= (int)$r['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                    aria-label="Usuń rezerwację #<?= (int)$r['id'] ?>">
                                                Usuń
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>