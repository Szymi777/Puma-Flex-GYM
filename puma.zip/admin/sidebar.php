<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav class="admin-sidebar" role="navigation" aria-label="Menu panelu administratora">
    <div class="admin-sidebar-title">⚙️ Panel Admina</div>
    <ul class="admin-nav" role="list">
        <li>
            <a href="/pumaflex/admin/index.php"
               class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">
                <span class="nav-icon" aria-hidden="true">📊</span> Dashboard
            </a>
        </li>
        <li>
            <a href="/pumaflex/admin/users.php"
               class="<?= $currentPage === 'users.php' ? 'active' : '' ?>">
                <span class="nav-icon" aria-hidden="true">👥</span> Użytkownicy
            </a>
        </li>
        <li>
            <a href="/pumaflex/admin/trainers.php"
               class="<?= $currentPage === 'trainers.php' ? 'active' : '' ?>">
                <span class="nav-icon" aria-hidden="true">🏋️</span> Trenerzy
            </a>
        </li>
        <li>
            <a href="/pumaflex/admin/reservations.php"
               class="<?= $currentPage === 'reservations.php' ? 'active' : '' ?>">
                <span class="nav-icon" aria-hidden="true">📅</span> Rezerwacje
            </a>
        </li>
        <li>
            <a href="/pumaflex/admin/messages.php"
               class="<?= $currentPage === 'messages.php' ? 'active' : '' ?>">
                <span class="nav-icon" aria-hidden="true">✉️</span> Wiadomości
            </a>
        </li>
        <li style="margin-top:auto;padding-top:20px;border-top:1px solid rgba(212,175,55,0.1);">
            <a href="/pumaflex/index.php">
                <span class="nav-icon" aria-hidden="true">🏠</span> Strona główna
            </a>
        </li>
        <li>
            <a href="/pumaflex/logout.php">
                <span class="nav-icon" aria-hidden="true">🚪</span> Wyloguj
            </a>
        </li>
    </ul>
</nav>