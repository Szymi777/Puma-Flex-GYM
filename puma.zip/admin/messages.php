<?php
/**
 * admin/messages.php – Podgląd i zarządzanie wiadomościami z formularza kontaktowego.
 */
require_once 'auth_guard.php';

$pageTitle = 'Wiadomości Kontaktowe';

// ----------------------------------------------------------------
// DELETE wiadomości
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowy token.'; header('Location: messages.php'); exit;
    }
    $del = $pdo->prepare('DELETE FROM kontakt WHERE id = :id');
    $del->execute([':id' => (int)$_POST['msg_id']]);
    $_SESSION['flash_success'] = 'Wiadomość usunięta.';
    header('Location: messages.php'); exit;
}

// Oznacz jako przeczytaną i wyświetl szczegóły
$viewMsg = null;
if (isset($_GET['id'])) {
    $msgId = (int)$_GET['id'];
    $stmtV = $pdo->prepare('SELECT * FROM kontakt WHERE id = :id');
    $stmtV->execute([':id' => $msgId]);
    $viewMsg = $stmtV->fetch() ?: null;

    if ($viewMsg && !$viewMsg['przeczytana']) {
        $upd = $pdo->prepare('UPDATE kontakt SET przeczytana = 1 WHERE id = :id');
        $upd->execute([':id' => $msgId]);
    }
}

// Pobierz wszystkie wiadomości
$msgs = $pdo->query(
    'SELECT id, name, email, LEFT(message, 100) AS msg_short, przeczytana, created_at
       FROM kontakt
      ORDER BY created_at DESC'
)->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

require_once dirname(__DIR__) . '/includes/header.php';
?>

<div class="admin-layout">
    <?php require_once 'sidebar.php'; ?>

    <main class="admin-main">
        <div class="admin-header">
            <h1>Wiadomości Kontaktowe</h1>
            <span style="color:var(--gray);font-size:14px;"><?= count($msgs) ?> wiadomości</span>
        </div>

        <?php if ($flashSuccess): ?>
            <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
        <?php endif; ?>

        <!-- Widok pełnej wiadomości -->
        <?php if ($viewMsg): ?>
            <div class="admin-form" style="margin-bottom:32px;border-color:var(--gold);">
                <div style="display:flex;justify-content:space-between;align-items:start;flex-wrap:wrap;gap:16px;margin-bottom:24px;">
                    <div>
                        <h3 style="color:var(--gold);margin-bottom:8px;">
                            ✉️ Wiadomość od: <?= e($viewMsg['name']) ?>
                        </h3>
                        <p style="color:var(--gray);font-size:14px;">
                            📧 <a href="mailto:<?= e($viewMsg['email']) ?>" style="color:var(--gold);"><?= e($viewMsg['email']) ?></a>
                            &nbsp;·&nbsp;
                            🕐 <?= date('d.m.Y H:i', strtotime($viewMsg['created_at'])) ?>
                        </p>
                    </div>
                    <form method="POST" action="messages.php"
                          onsubmit="return confirm('Usunąć tę wiadomość na stałe?')"
                          aria-label="Formularz usunięcia wiadomości">
                        <input type="hidden" name="action"     value="delete">
                        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="msg_id"     value="<?= (int)$viewMsg['id'] ?>">
                        <button type="submit" class="btn btn-danger btn-sm"
                                aria-label="Usuń wiadomość od <?= e($viewMsg['name']) ?>">
                            🗑️ Usuń wiadomość
                        </button>
                    </form>
                </div>
                <div style="background:var(--dark3);padding:24px;border-radius:var(--radius);font-size:15px;line-height:1.8;color:rgba(245,245,245,0.9);white-space:pre-wrap;">
                    <?= e($viewMsg['message']) ?>
                </div>
                <div style="margin-top:20px;">
                    <a href="messages.php" class="btn btn-secondary btn-sm" aria-label="Wróć do listy wiadomości">
                        ← POWRÓT DO LISTY
                    </a>
                    <a href="mailto:<?= e($viewMsg['email']) ?>?subject=Re: PUMA FLEX"
                       class="btn btn-primary btn-sm"
                       style="margin-left:12px;"
                       aria-label="Odpowiedz emailem do <?= e($viewMsg['name']) ?>">
                        📧 ODPOWIEDZ EMAILEM
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <!-- Tabela wiadomości -->
        <div class="admin-table-wrapper">
            <table class="admin-table" aria-label="Tabela wiadomości z formularza kontaktowego">
                <thead>
                    <tr>
                        <th scope="col">Status</th>
                        <th scope="col">Nadawca</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Fragment wiadomości</th>
                        <th scope="col">Data</th>
                        <th scope="col">Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($msgs)): ?>
                        <tr>
                            <td colspan="6" style="text-align:center;color:var(--gray);padding:30px;">
                                Brak wiadomości.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($msgs as $m): ?>
                            <tr style="<?= !$m['przeczytana'] ? 'font-weight:600;' : 'opacity:0.75;' ?>">
                                <td>
                                    <span
                                        title="<?= $m['przeczytana'] ? 'Przeczytana' : 'Nowa' ?>"
                                        aria-label="Status: <?= $m['przeczytana'] ? 'Przeczytana' : 'Nowa wiadomość' ?>"
                                        style="font-size:18px;"
                                    >
                                        <?= $m['przeczytana'] ? '✓' : '🔴' ?>
                                    </span>
                                </td>
                                <td><?= e($m['name']) ?></td>
                                <td><?= e($m['email']) ?></td>
                                <td style="color:var(--gray);font-size:13px;"><?= e($m['msg_short']) ?>...</td>
                                <td style="font-size:13px;"><?= date('d.m.Y H:i', strtotime($m['created_at'])) ?></td>
                                <td>
                                    <div class="admin-actions">
                                        <a href="messages.php?id=<?= (int)$m['id'] ?>"
                                           class="btn btn-primary btn-sm"
                                           aria-label="Czytaj pełną wiadomość od <?= e($m['name']) ?>">
                                            Czytaj
                                        </a>
                                        <form method="POST" action="messages.php" style="display:inline;"
                                              onsubmit="return confirm('Usunąć wiadomość od <?= e($m['name']) ?>?')">
                                            <input type="hidden" name="action"     value="delete">
                                            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                            <input type="hidden" name="msg_id"     value="<?= (int)$m['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm"
                                                    aria-label="Usuń wiadomość od <?= e($m['name']) ?>">
                                                Usuń
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once dirname(__DIR__) . '/includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>