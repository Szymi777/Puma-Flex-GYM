<?php
/**
 * admin/auth_guard.php
 * Zabezpieczenie panelu admina.
 * Dołączany na samej górze każdego pliku w katalogu admin/.
 */

// Ścieżka względem pliku admin/*.php
require_once dirname(__DIR__) . '/includes/auth.php';
require_once dirname(__DIR__) . '/includes/db.php';

requireAdmin();

// Generuj CSRF token jeśli brak
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}