<?php
/**
 * vip.php – Strefa VIP (opis marketingowy + placeholder sauna).
 */
require_once 'includes/auth.php';
$pageTitle = 'Strefa VIP';
require_once 'includes/header.php';
?>

<main>
<section class="vip-section" aria-labelledby="vip-title">
    <h2 class="section-title" id="vip-title">Strefa <span class="gold">VIP</span></h2>

    <!-- Główna sekcja hero VIP -->
    <div class="vip-hero">
        <div class="vip-text">
            <h2>Regeneracja na <span class="gold">Najwyższym Poziomie</span></h2>
            <p>
                PUMA FLEX VIP to nie tylko siłownia – to kompletne centrum wellness dla osób,
                które traktują swoje ciało poważnie. Po intensywnym treningu Twoje mięśnie
                i umysł potrzebują prawdziwej regeneracji.
            </p>
            <p>
                Nasza ekskluzywna <strong style="color:var(--gold);">sauna fińska</strong> o pojemności
                8 osób osiąga temperatury do 95°C, zapewniając głębokie rozluźnienie mięśni,
                oczyszczanie porów i poprawę krążenia. Complementarnie,
                <strong style="color:var(--gold);">sauna infrared</strong> działa na głębsze
                warstwy tkanek, przyspieszając eliminację kwasu mlekowego nawet o 40%.
            </p>
            <p>
                Strefa VIP obejmuje również jacuzzi z hydromasażem, lodowatą wannę do
                <strong style="color:var(--gold);">cold therapy</strong>, prywatne kabiny
                prysznicowe z aromaterapią oraz ekskluzywny lounge z napojami izotonicznymi.
            </p>
            <a href="karnety.php" class="btn btn-primary" aria-label="Sprawdź karnety dające dostęp do strefy VIP">
                ODBLOKUJ STREFĘ VIP
            </a>
        </div>

        <div class="vip-image">
            <img
                src="assets/img/bg_vip.jpg"
                alt="Luksusowa sauna fińska w strefie VIP siłowni PUMA FLEX – drewniane wnętrze, kamienne piece, eksluzywna atmosfera"
                loading="lazy"
            >
        </div>
    </div>

    <!-- Korzyści VIP -->
    <div class="vip-benefits" role="list" aria-label="Korzyści strefy VIP PUMA FLEX">

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">🔥</span>
            <h4>Sauna Fińska</h4>
            <p>Do 95°C, pojemność 8 osób. Klasyczna para z aromatami eukaliptusa i mięty.</p>
        </div>

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">☀️</span>
            <h4>Sauna Infrared</h4>
            <p>Głęboka regeneracja tkanek. Redukcja bólu mięśniowego i poprawa elastyczności.</p>
        </div>

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">❄️</span>
            <h4>Cold Therapy</h4>
            <p>Lodowata wanna 8–12°C. Zmniejsza stan zapalny i skraca czas regeneracji o połowę.</p>
        </div>

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">💆</span>
            <h4>Jacuzzi</h4>
            <p>Hydromasaż 12-dysz. Rozluźnienie napiętych mięśni i poprawa przepływu krwi.</p>
        </div>

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">🛁</span>
            <h4>Prywatne Kabiny</h4>
            <p>Prysznice z aromaterapią i muzyką. Własna przestrzeń bez kompromisów.</p>
        </div>

        <div class="vip-benefit-item" role="listitem">
            <span class="benefit-icon" aria-hidden="true">🍹</span>
            <h4>VIP Lounge</h4>
            <p>Napoje izotoniczne, koktajle proteinowe i zdrowe przekąski. Ekskluzywna atmosfera.</p>
        </div>

    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>