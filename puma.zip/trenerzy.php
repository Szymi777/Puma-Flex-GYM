<?php
/**
 * trenerzy.php – Siatka trenerów 3x2.
 * Przycisk "Umów trening" przekierowuje niezalogowanych do login.php.
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Nasi Trenerzy';

// Pobierz trenerów z bazy (tylko aktywni, limit 6 dla układu 3x2)
$stmt = $pdo->prepare(
    'SELECT id, imie_nazwisko, specjalizacja, opis, zdjecie
       FROM trenerzy
      WHERE aktywny = 1
      ORDER BY id ASC
      LIMIT 6'
);
$stmt->execute();
$trenerzy = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<main>
<section
    style="padding-top: calc(var(--nav-height) + 80px); min-height: 100vh;
           background: linear-gradient(to bottom, rgba(0,0,0,0.8), var(--black)),
                       url('assets/img/bg3.jpg') center/cover no-repeat;"
    aria-labelledby="trenerzy-title"
>
    <h2 class="section-title" id="trenerzy-title">Nasi <span class="gold">Trenerzy</span></h2>
    <p style="text-align:center;color:var(--gray);font-size:16px;margin-top:-40px;margin-bottom:60px;">
        Mistrzowie, mentorzy, eksperci. Twój sukces to nasza misja.
    </p>

    <?php if (empty($trenerzy)): ?>
        <div class="alert alert-info" style="max-width:600px;margin:0 auto;">
            Trwają przygotowania do prezentacji naszych trenerów. Zapraszamy wkrótce!
        </div>
    <?php else: ?>
        <div class="trainers-grid" role="list" aria-label="Lista trenerów PUMA FLEX">

            <?php foreach ($trenerzy as $t): ?>
                <article class="trainer-card" role="listitem" aria-label="Trener: <?= e($t['imie_nazwisko']) ?>">
                    <img
                        src="<?= e($t['zdjecie']) ?>"
                        alt="Zdjęcie trenera <?= e($t['imie_nazwisko']) ?> – specjalista: <?= e($t['specjalizacja']) ?>"
                        loading="lazy"
                        onerror="this.src='assets/img/trener_placeholder.jpg'"
                    >
                    <div class="trainer-body">
                        <h3><?= e($t['imie_nazwisko']) ?></h3>
                        <p class="trainer-spec"><?= e($t['specjalizacja']) ?></p>
                        <p><?= e($t['opis']) ?></p>
                        <div class="trainer-footer">
                            <?php if (isLoggedIn()): ?>
                                <a
                                    href="rezerwacja.php?trener=<?= (int)$t['id'] ?>"
                                    class="btn btn-primary btn-sm"
                                    aria-label="Umów trening z <?= e($t['imie_nazwisko']) ?>"
                                >
                                    Umów trening
                                </a>
                            <?php else: ?>
                                <a
                                    href="login.php"
                                    class="btn btn-secondary btn-sm"
                                    aria-label="Zaloguj się, aby umówić trening z <?= e($t['imie_nazwisko']) ?>"
                                    title="Zaloguj się, aby umówić trening"
                                >
                                    Umów trening
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>

        </div>
    <?php endif; ?>

</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>