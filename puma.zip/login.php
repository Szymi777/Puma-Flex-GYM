<?php
/**
 * login.php
 * Obsługuje logowanie i rejestrację na jednej stronie (zakładki).
 * Bezpieczne hasła: password_hash / password_verify.
 * Ochrona: Prepared Statements, CSRF, htmlspecialchars.
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Jeśli już zalogowany – przekieruj
if (isLoggedIn()) {
    header('Location: profil.php');
    exit;
}

$pageTitle   = 'Logowanie i Rejestracja';
$activeTab   = 'login'; // domyślna zakładka
$loginErrors = [];
$regErrors   = [];

// Generuj CSRF token jeśli brak
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ----------------------------------------------------------------
// Obsługa formularza LOGOWANIA
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
    $activeTab = 'login';

    // Weryfikacja CSRF
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $loginErrors[] = 'Nieprawidłowe żądanie. Odśwież stronę.';
    } else {
        $email  = trim($_POST['email']  ?? '');
        $haslo  = trim($_POST['haslo']  ?? '');

        if ($email === '') { $loginErrors[] = 'Podaj adres e-mail.'; }
        if ($haslo === '') { $loginErrors[] = 'Podaj hasło.'; }

        if (empty($loginErrors)) {
            $stmt = $pdo->prepare(
                'SELECT id, imie, nazwisko, haslo, rola FROM uzytkownicy WHERE email = :email LIMIT 1'
            );
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if ($user && password_verify($haslo, $user['haslo'])) {
                // Regeneruj ID sesji po logowaniu (ochrona przed Session Fixation)
                session_regenerate_id(true);

                $_SESSION['user_id']    = $user['id'];
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name']  = $user['imie'] . ' ' . $user['nazwisko'];
                $_SESSION['user_role']  = $user['rola'];

                // Odśwież hash jeśli algorytm jest przestarzały
                if (password_needs_rehash($user['haslo'], PASSWORD_DEFAULT)) {
                    $newHash = password_hash($haslo, PASSWORD_DEFAULT);
                    $upd = $pdo->prepare('UPDATE uzytkownicy SET haslo = :h WHERE id = :id');
                    $upd->execute([':h' => $newHash, ':id' => $user['id']]);
                }

                // Przekieruj admina do panelu, użytkownika do profilu
                if ($user['rola'] === 'admin') {
                    header('Location: admin/index.php');
                } else {
                    header('Location: profil.php');
                }
                exit;
            } else {
                // Opóźnienie brute-force
                usleep(500000); // 0.5 sekundy
                $loginErrors[] = 'Nieprawidłowy adres e-mail lub hasło.';
            }
        }
    }
}

// ----------------------------------------------------------------
// Obsługa formularza REJESTRACJI
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'register') {
    $activeTab = 'register';

    // Weryfikacja CSRF
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $regErrors[] = 'Nieprawidłowe żądanie. Odśwież stronę.';
    } else {
        $imie    = trim($_POST['imie']    ?? '');
        $nazwisko= trim($_POST['nazwisko']?? '');
        $email   = trim($_POST['email']   ?? '');
        $haslo   = $_POST['haslo']        ?? '';
        $haslo2  = $_POST['haslo2']       ?? '';

        // Walidacja
        if ($imie === '' || mb_strlen($imie) < 2)      { $regErrors[] = 'Podaj imię (min. 2 znaki).'; }
        if ($nazwisko === '' || mb_strlen($nazwisko) < 2){ $regErrors[] = 'Podaj nazwisko (min. 2 znaki).'; }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $regErrors[] = 'Nieprawidłowy adres e-mail.'; }
        if (mb_strlen($haslo) < 8)                      { $regErrors[] = 'Hasło musi mieć co najmniej 8 znaków.'; }
        if (!preg_match('/[A-Z]/', $haslo))             { $regErrors[] = 'Hasło musi zawierać co najmniej jedną wielką literę.'; }
        if (!preg_match('/[0-9]/', $haslo))             { $regErrors[] = 'Hasło musi zawierać co najmniej jedną cyfrę.'; }
        if ($haslo !== $haslo2)                         { $regErrors[] = 'Hasła nie są identyczne.'; }

        if (empty($regErrors)) {
            // Sprawdź czy e-mail już istnieje
            $chk = $pdo->prepare('SELECT id FROM uzytkownicy WHERE email = :email LIMIT 1');
            $chk->execute([':email' => $email]);
            if ($chk->fetch()) {
                $regErrors[] = 'Konto z tym adresem e-mail już istnieje.';
            } else {
                // Hashuj hasło
                $hash = password_hash($haslo, PASSWORD_DEFAULT);

                $ins = $pdo->prepare(
                    'INSERT INTO uzytkownicy (imie, nazwisko, email, haslo, rola)
                     VALUES (:imie, :nazwisko, :email, :haslo, "user")'
                );
                $ins->execute([
                    ':imie'     => $imie,
                    ':nazwisko' => $nazwisko,
                    ':email'    => $email,
                    ':haslo'    => $hash,
                ]);

                // Automatyczne zalogowanie po rejestracji
                session_regenerate_id(true);
                $_SESSION['user_id']    = (int)$pdo->lastInsertId();
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name']  = $imie . ' ' . $nazwisko;
                $_SESSION['user_role']  = 'user';

                $_SESSION['flash_success'] = 'Witaj w PUMA FLEX, ' . $imie . '! Twoje konto zostało utworzone.';
                header('Location: profil.php');
                exit;
            }
        }
    }
}

require_once 'includes/header.php';
?>

<main>
<div class="auth-page">
    <div class="auth-box">
        <!-- Logo -->
        <div class="auth-logo">
            <img src="assets/img/logo.png" alt="Logo PUMA FLEX">
            <p>Siłownia Premium</p>
        </div>

        <!-- Flash info (np. przekierowanie z chronionej strony) -->
        <?php $flashInfo = getFlash('flash_error'); ?>
        <?php if ($flashInfo): ?>
            <div class="alert alert-info" role="alert"><?= e($flashInfo) ?></div>
        <?php endif; ?>

        <!-- Zakładki -->
        <div class="auth-tabs" role="tablist" aria-label="Wybierz: logowanie lub rejestracja">
            <button
                class="auth-tab <?= $activeTab === 'login' ? 'active' : '' ?>"
                role="tab"
                aria-selected="<?= $activeTab === 'login' ? 'true' : 'false' ?>"
                aria-controls="panel-login"
                id="tab-login"
                onclick="switchTab('login')"
            >Logowanie</button>
            <button
                class="auth-tab <?= $activeTab === 'register' ? 'active' : '' ?>"
                role="tab"
                aria-selected="<?= $activeTab === 'register' ? 'true' : 'false' ?>"
                aria-controls="panel-register"
                id="tab-register"
                onclick="switchTab('register')"
            >Rejestracja</button>
        </div>

        <!-- Panel: LOGOWANIE -->
        <div
            id="panel-login"
            class="auth-panel <?= $activeTab === 'login' ? 'active' : '' ?>"
            role="tabpanel"
            aria-labelledby="tab-login"
        >
            <?php if (!empty($loginErrors)): ?>
                <div class="alert alert-error" role="alert">
                    <?php foreach ($loginErrors as $err): ?>
                        <p><?= e($err) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php" novalidate aria-label="Formularz logowania">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="form-group">
                    <label for="login-email">Adres e-mail</label>
                    <input
                        type="email"
                        id="login-email"
                        name="email"
                        placeholder="twoj@email.pl"
                        required
                        autocomplete="email"
                        aria-required="true"
                        value="<?= e($_POST['email'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="login-haslo">Hasło</label>
                    <input
                        type="password"
                        id="login-haslo"
                        name="haslo"
                        placeholder="••••••••"
                        required
                        autocomplete="current-password"
                        aria-required="true"
                    >
                </div>

                <button type="submit" class="btn btn-primary btn-full" aria-label="Zaloguj się do konta PUMA FLEX">
                    ZALOGUJ SIĘ
                </button>
            </form>

            <p class="auth-footer-link">
                Nie masz konta?
                <a href="#" onclick="switchTab('register'); return false;" aria-label="Przejdź do rejestracji">
                    Zarejestruj się
                </a>
            </p>
        </div>

        <!-- Panel: REJESTRACJA -->
        <div
            id="panel-register"
            class="auth-panel <?= $activeTab === 'register' ? 'active' : '' ?>"
            role="tabpanel"
            aria-labelledby="tab-register"
        >
            <?php if (!empty($regErrors)): ?>
                <div class="alert alert-error" role="alert">
                    <?php foreach ($regErrors as $err): ?>
                        <p><?= e($err) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php" novalidate aria-label="Formularz rejestracji nowego konta">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <div class="form-group">
                    <label for="reg-imie">Imię</label>
                    <input
                        type="text"
                        id="reg-imie"
                        name="imie"
                        placeholder="Jan"
                        required
                        autocomplete="given-name"
                        aria-required="true"
                        value="<?= e($_POST['imie'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="reg-nazwisko">Nazwisko</label>
                    <input
                        type="text"
                        id="reg-nazwisko"
                        name="nazwisko"
                        placeholder="Kowalski"
                        required
                        autocomplete="family-name"
                        aria-required="true"
                        value="<?= e($_POST['nazwisko'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="reg-email">Adres e-mail</label>
                    <input
                        type="email"
                        id="reg-email"
                        name="email"
                        placeholder="twoj@email.pl"
                        required
                        autocomplete="email"
                        aria-required="true"
                        value="<?= e($_POST['email'] ?? '') ?>"
                    >
                </div>

                <div class="form-group">
                    <label for="reg-haslo">
                        Hasło
                        <span style="font-size:11px;font-weight:400;color:var(--gray);">
                            (min. 8 znaków, wielka litera, cyfra)
                        </span>
                    </label>
                    <input
                        type="password"
                        id="reg-haslo"
                        name="haslo"
                        placeholder="••••••••"
                        required
                        autocomplete="new-password"
                        aria-required="true"
                        aria-describedby="haslo-hint"
                    >
                </div>

                <div class="form-group">
                    <label for="reg-haslo2">Powtórz hasło</label>
                    <input
                        type="password"
                        id="reg-haslo2"
                        name="haslo2"
                        placeholder="••••••••"
                        required
                        autocomplete="new-password"
                        aria-required="true"
                    >
                </div>

                <button type="submit" class="btn btn-primary btn-full" aria-label="Utwórz nowe konto w PUMA FLEX">
                    UTWÓRZ KONTO
                </button>
            </form>

            <p class="auth-footer-link">
                Masz już konto?
                <a href="#" onclick="switchTab('login'); return false;" aria-label="Przejdź do logowania">
                    Zaloguj się
                </a>
            </p>
        </div>
    </div>
</div>
</main>

<?php require_once 'includes/footer.php'; ?>

<script>
function switchTab(tab) {
    // Zaktualizuj przyciski zakładek
    document.querySelectorAll('.auth-tab').forEach(function(btn) {
        btn.classList.remove('active');
        btn.setAttribute('aria-selected', 'false');
    });
    document.querySelectorAll('.auth-panel').forEach(function(panel) {
        panel.classList.remove('active');
    });

    var activeBtn   = document.getElementById('tab-' + tab);
    var activePanel = document.getElementById('panel-' + tab);

    if (activeBtn && activePanel) {
        activeBtn.classList.add('active');
        activeBtn.setAttribute('aria-selected', 'true');
        activePanel.classList.add('active');
    }
}
</script>
</body>
</html>