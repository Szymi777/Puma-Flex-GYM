<?php
/**
 * karnety.php – Podstrona z ofertą karnetów.
 */
require_once 'includes/auth.php';
$pageTitle = 'Karnety Premium';
require_once 'includes/header.php';
?>

<main>
<section class="pricing-section" aria-labelledby="karnety-title">
    <h2 class="section-title" id="karnety-title">Karnety <span class="gold">Premium</span></h2>
    <p style="text-align:center;color:var(--gray);font-size:16px;margin-top:-40px;margin-bottom:60px;">
        Wybierz plan dopasowany do Twoich ambicji. Bez ukrytych opłat, bez kompromisów.
    </p>

    <div class="pricing-grid">

        <!-- STANDARD -->
        <article class="price-card" aria-label="Karnet Standard – 100 złotych miesięcznie">
            <h3>STANDARD</h3>
            <div class="price-amount" aria-label="Cena: 100 złotych">100 <small style="font-size:28px;">zł</small></div>
            <p class="price-period">miesięcznie</p>
            <ul class="price-features" aria-label="Co zawiera karnet Standard">
                <li>Nielimitowany dostęp do siłowni</li>
                <li>Strefa cardio i siłowa</li>
                <li>Szatnia i prysznice</li>
                <li>Dostęp w godzinach otwarcia</li>
                <li>Aplikacja mobilna PUMA FLEX</li>
            </ul>
            <a href="<?= isLoggedIn() ? 'rezerwacja.php' : 'login.php' ?>"
               class="btn btn-secondary btn-full"
               aria-label="Kup karnet Standard za 100 złotych">
                WYBIERZ PLAN
            </a>
        </article>

        <!-- ELITE (wyróżniony) -->
        <article class="price-card featured" aria-label="Karnet Elite – 250 złotych miesięcznie – najpopularniejszy">
            <span class="price-badge">⭐ NAJPOPULARNIEJSZY</span>
            <h3>ELITE</h3>
            <div class="price-amount" aria-label="Cena: 250 złotych">250 <small style="font-size:28px;">zł</small></div>
            <p class="price-period">miesięcznie</p>
            <ul class="price-features" aria-label="Co zawiera karnet Elite">
                <li>Wszystko z planu Standard</li>
                <li>2 treningi z trenerem/miesiąc</li>
                <li>Dostęp do strefy VIP</li>
                <li>Sauna fińska</li>
                <li>Plan treningowy online</li>
                <li>Konsultacja dietetyczna</li>
            </ul>
            <a href="<?= isLoggedIn() ? 'rezerwacja.php' : 'login.php' ?>"
               class="btn btn-primary btn-full"
               aria-label="Kup karnet Elite za 250 złotych – najpopularniejszy wybór">
                WYBIERZ PLAN
            </a>
        </article>

        <!-- GYMBRO -->
        <article class="price-card" aria-label="Karnet GYMBRO – 500 złotych miesięcznie – oferta premium all-inclusive">
            <h3>GYMBRO</h3>
            <div class="price-amount" aria-label="Cena: 500 złotych">500 <small style="font-size:28px;">zł</small></div>
            <p class="price-period">miesięcznie</p>
            <ul class="price-features" aria-label="Co zawiera karnet GYMBRO">
                <li>Wszystko z planu Elite</li>
                <li>Nielimitowane treningi z trenerem</li>
                <li>Pełna strefa VIP (sauna + jacuzzi)</li>
                <li>Indywidualny plan diety</li>
                <li>Priorytetowe rezerwacje</li>
                <li>Parking VIP</li>
                <li>Wsparcie 24/7</li>
            </ul>
            <a href="<?= isLoggedIn() ? 'rezerwacja.php' : 'login.php' ?>"
               class="btn btn-secondary btn-full"
               aria-label="Kup karnet GYMBRO za 500 złotych – oferta all-inclusive">
                WYBIERZ PLAN
            </a>
        </article>

    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
// Hamburger (wspólny skrypt nav)
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>