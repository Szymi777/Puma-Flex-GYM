<?php
/**
 * logout.php – Bezpieczne wylogowanie użytkownika.
 */
require_once 'includes/auth.php';

// Wyczyść wszystkie zmienne sesji
$_SESSION = [];

// Usuń ciasteczko sesji
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}

// Zniszcz sesję
session_destroy();

// Przekieruj na stronę główną z komunikatem
session_start();
$_SESSION['flash_info'] = 'Zostałeś pomyślnie wylogowany.';
header('Location: index.php');
exit;