<?php
/**
 * profil.php – Profil zalogowanego użytkownika.
 * Wyświetla dane konta i listę rezerwacji z możliwością odwołania.
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

requireLogin('login.php');

$pageTitle = 'Mój Profil';

// Generuj CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$userId = (int)$_SESSION['user_id'];

// ----------------------------------------------------------------
// Odwołanie rezerwacji przez użytkownika
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'cancel_reservation') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $_SESSION['flash_error'] = 'Nieprawidłowe żądanie.';
    } else {
        $rezId = (int)($_POST['rez_id'] ?? 0);
        // Upewnij się, że rezerwacja należy do zalogowanego użytkownika
        $upd = $pdo->prepare(
            'UPDATE rezerwacje SET status = "odwolana"
              WHERE id = :rid AND uzytkownik_id = :uid AND status = "oczekujaca"'
        );
        $upd->execute([':rid' => $rezId, ':uid' => $userId]);
        if ($upd->rowCount() > 0) {
            $_SESSION['flash_success'] = 'Rezerwacja została odwołana.';
        } else {
            $_SESSION['flash_error'] = 'Nie można odwołać tej rezerwacji (już odwołana lub potwierdzona przez trenera).';
        }
    }
    header('Location: profil.php');
    exit;
}

// Pobierz dane użytkownika
$stmtU = $pdo->prepare('SELECT imie, nazwisko, email, rola, created_at FROM uzytkownicy WHERE id = :id');
$stmtU->execute([':id' => $userId]);
$user = $stmtU->fetch();

// Pobierz rezerwacje użytkownika (wraz z danymi trenera)
$stmtR = $pdo->prepare(
    'SELECT r.id, r.data_treningu, r.godzina_od, r.godzina_do, r.notatka, r.status, r.created_at,
            t.imie_nazwisko AS trener_name, t.specjalizacja AS trener_spec
       FROM rezerwacje r
       JOIN trenerzy t ON t.id = r.trener_id
      WHERE r.uzytkownik_id = :uid
      ORDER BY r.data_treningu DESC, r.godzina_od DESC'
);
$stmtR->execute([':uid' => $userId]);
$rezerwacje = $stmtR->fetchAll();

$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');

require_once 'includes/header.php';

// Inicjały dla avatara
$initials = mb_strtoupper(mb_substr($user['imie'], 0, 1) . mb_substr($user['nazwisko'], 0, 1));
?>

<main>
<section class="profil-section" aria-labelledby="profil-title">
    <h2 class="section-title" id="profil-title" style="text-align:left;margin-bottom:40px;">
        Mój <span class="gold">Profil</span>
    </h2>

    <?php if ($flashSuccess): ?>
        <div class="alert alert-success" role="alert"><?= e($flashSuccess) ?></div>
    <?php endif; ?>
    <?php if ($flashError): ?>
        <div class="alert alert-error" role="alert"><?= e($flashError) ?></div>
    <?php endif; ?>

    <div class="profil-grid">
        <!-- Sidebar -->
        <aside class="profil-sidebar" aria-label="Informacje o koncie użytkownika">
            <div class="profil-avatar" aria-hidden="true"><?= e($initials) ?></div>
            <h3><?= e($user['imie'] . ' ' . $user['nazwisko']) ?></h3>
            <span class="role-badge">
                <?= $user['rola'] === 'admin' ? '👑 Administrator' : '🏋️ Członek' ?>
            </span>

            <p style="font-size:13px;color:var(--gray);text-align:center;margin-bottom:20px;">
                <?= e($user['email']) ?>
            </p>
            <p style="font-size:12px;color:var(--gray);text-align:center;margin-bottom:28px;">
                Konto od: <?= date('d.m.Y', strtotime($user['created_at'])) ?>
            </p>

            <nav aria-label="Menu profilu użytkownika">
                <ul class="profil-nav">
                    <li>
                        <a href="profil.php" class="active" aria-label="Moje rezerwacje treningów">
                            📅 Moje Rezerwacje
                        </a>
                    </li>
                    <li>
                        <a href="rezerwacja.php" aria-label="Zarezerwuj nowy trening personalny">
                            ➕ Nowa Rezerwacja
                        </a>
                    </li>
                    <?php if (isAdmin()): ?>
                        <li>
                            <a href="admin/index.php" aria-label="Panel administratora PUMA FLEX">
                                ⚙️ Panel Admina
                            </a>
                        </li>
                    <?php endif; ?>
                    <li>
                        <a href="logout.php" aria-label="Wyloguj się z konta PUMA FLEX">
                            🚪 Wyloguj
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Treść główna -->
        <div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;flex-wrap:wrap;gap:16px;">
                <h3 style="font-size:22px;color:var(--gold);">Moje Rezerwacje</h3>
                <a href="rezerwacja.php" class="btn btn-primary btn-sm" aria-label="Zarezerwuj nowy trening personalny">
                    + NOWA REZERWACJA
                </a>
            </div>

            <?php if (empty($rezerwacje)): ?>
                <div class="alert alert-info" role="status">
                    Nie masz jeszcze żadnych rezerwacji. 
                    <a href="rezerwacja.php" style="color:var(--gold);font-weight:600;">Zarezerwuj pierwszy trening!</a>
                </div>
            <?php else: ?>
                <div class="reservation-list" role="list" aria-label="Lista Twoich rezerwacji treningów">
                    <?php foreach ($rezerwacje as $r): ?>
                        <article class="reservation-item" role="listitem">
                            <div class="reservation-info">
                                <h4><?= e($r['trener_name']) ?></h4>
                                <p><?= e($r['trener_spec']) ?></p>
                                <p style="margin-top:8px;">
                                    📅 <?= date('d.m.Y (l)', strtotime($r['data_treningu'])) ?>
                                    &nbsp;|&nbsp;
                                    🕐 <?= substr($r['godzina_od'], 0, 5) ?>–<?= substr($r['godzina_do'], 0, 5) ?>
                                </p>
                                <?php if ($r['notatka']): ?>
                                    <p style="font-size:13px;color:var(--gray);margin-top:6px;">
                                        💬 <?= e($r['notatka']) ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div style="display:flex;flex-direction:column;align-items:flex-end;gap:12px;">
                                <span
                                    class="status-badge status-<?= e($r['status']) ?>"
                                    aria-label="Status rezerwacji: <?= e($r['status']) ?>"
                                >
                                    <?= ucfirst(e($r['status'])) ?>
                                </span>
                                <?php if ($r['status'] === 'oczekujaca' && strtotime($r['data_treningu']) > time()): ?>
                                    <form method="POST" action="profil.php"
                                          onsubmit="return confirm('Czy na pewno chcesz odwołać tę rezerwację?')">
                                        <input type="hidden" name="action"     value="cancel_reservation">
                                        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="rez_id"     value="<?= (int)$r['id'] ?>">
                                        <button
                                            type="submit"
                                            class="btn btn-danger btn-sm"
                                            aria-label="Odwołaj rezerwację treningu <?= date('d.m.Y', strtotime($r['data_treningu'])) ?> o <?= substr($r['godzina_od'],0,5) ?>"
                                        >
                                            Odwołaj
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>