<?php
/**
 * index.php – Strona główna serwisu PUMA FLEX
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

$pageTitle = 'Siłownia Premium';

// Flash messages ze stron zewnętrznych (np. po kontakcie)
$flashSuccess = getFlash('flash_success');
$flashError   = getFlash('flash_error');
$flashInfo    = getFlash('flash_info');

require_once 'includes/header.php';
?>

<main>
    <!-- ===================== HERO ===================== -->
    <section class="hero" aria-labelledby="hero-heading">
        <div class="hero-content">
            <p class="hero-eyebrow">Siłownia Premium · Warszawa</p>
            <h2 id="hero-heading">
                ZBUDUJ <span class="gold">NAJSILNIEJSZĄ</span><br>WERSJĘ SIEBIE
            </h2>
            <p class="hero-desc">
                Ekskluzywna siłownia dla ludzi, którzy nie uznają kompromisów.
                Sprzęt klasy światowej, trenerzy mistrzów, strefa regeneracji VIP.
            </p>
            <div class="hero-buttons">
                <a href="karnety.php" class="btn btn-primary" aria-label="Sprawdź dostępne karnety i dołącz do PUMA FLEX">
                    DOŁĄCZ TERAZ
                </a>
                <a href="#oferta" class="btn btn-secondary" aria-label="Dowiedz się więcej o ofercie">
                    POZNAJ OFERTĘ
                </a>
            </div>
        </div>
    </section>

    <!-- Flash messages globalne -->
    <?php if ($flashSuccess): ?>
        <div role="alert" style="padding: 0 10%; margin-top: -20px; margin-bottom: 20px;">
            <div class="alert alert-success"><?= e($flashSuccess) ?></div>
        </div>
    <?php endif; ?>
    <?php if ($flashError): ?>
        <div role="alert" style="padding: 0 10%; margin-top: -20px; margin-bottom: 20px;">
            <div class="alert alert-error"><?= e($flashError) ?></div>
        </div>
    <?php endif; ?>
    <?php if ($flashInfo): ?>
        <div role="alert" style="padding: 0 10%; margin-top: -20px; margin-bottom: 20px;">
            <div class="alert alert-info"><?= e($flashInfo) ?></div>
        </div>
    <?php endif; ?>

    <!-- ===================== OFERTA / FEATURES ===================== -->
    <section id="oferta" aria-labelledby="oferta-title">
        <h2 class="section-title" id="oferta-title">Dlaczego <span class="gold">PUMA FLEX</span>?</h2>
        <div class="features-grid">

            <!-- Karta 1: Sprzęt -->
            <article class="feature-card"
                     role="button"
                     tabindex="0"
                     aria-label="Przejdź do galerii sprzętu klasy światowej"
                     onclick="window.location.href='galeria.php'"
                     onkeydown="if(event.key==='Enter'||event.key===' '){window.location.href='galeria.php'}">
                <span class="feature-icon" aria-hidden="true">🏋️</span>
                <h3>Sprzęt klasy światowej</h3>
                <p>Najnowsze maszyny Technogym i Hammer Strength. Ponad 200 stanowisk treningowych w jednym miejscu.</p>
                <a href="galeria.php" class="btn btn-primary btn-sm" aria-label="Zobacz galerię sprzętu siłowni">
                    ZOBACZ GALERIĘ
                </a>
            </article>

            <!-- Karta 2: Trenerzy -->
            <article class="feature-card"
                     role="button"
                     tabindex="0"
                     aria-label="Przejdź do strony trenerów elity"
                     onclick="window.location.href='trenerzy.php'"
                     onkeydown="if(event.key==='Enter'||event.key===' '){window.location.href='trenerzy.php'}">
                <span class="feature-icon" aria-hidden="true">🥇</span>
                <h3>Trenerzy elity</h3>
                <p>Mistrzowie Polski i certyfikowani eksperci. Każdy program treningowy tworzony indywidualnie pod Twoje cele.</p>
                <a href="trenerzy.php" class="btn btn-primary btn-sm" aria-label="Poznaj naszych trenerów i umów trening">
                    POZNAJ TRENERÓW
                </a>
            </article>

            <!-- Karta 3: Strefa VIP -->
            <article class="feature-card"
                     role="button"
                     tabindex="0"
                     aria-label="Przejdź do opisu strefy VIP"
                     onclick="window.location.href='vip.php'"
                     onkeydown="if(event.key==='Enter'||event.key===' '){window.location.href='vip.php'}">
                <span class="feature-icon" aria-hidden="true">👑</span>
                <h3>Strefa VIP</h3>
                <p>Prywatne treningi, sauna fińska i infrared, jacuzzi, lounge dla członków premium. Regeneracja na najwyższym poziomie.</p>
                <a href="vip.php" class="btn btn-primary btn-sm" aria-label="Dowiedz się więcej o strefie VIP">
                    ODKRYJ STREFĘ VIP
                </a>
            </article>

        </div>
    </section>

    <!-- ===================== KONTAKT / FOOTER ===================== -->
    <section id="kontakt" class="contact-section" aria-labelledby="kontakt-title">
        <h2 class="section-title" id="kontakt-title">Skontaktuj się <span class="gold">z nami</span></h2>

        <div class="contact-grid">
            <!-- Informacje kontaktowe -->
            <div class="contact-info">
                <h3>PUMA FLEX Warszawa</h3>
                <p>
                    Masz pytania dotyczące karnetu, oferty treningowej lub chcesz umówić
                    się na bezpłatne zwiedzanie siłowni? Napisz do nas – odpowiemy
                    w ciągu 24 godzin.
                </p>
                <div class="contact-detail">
                    <span class="icon" aria-hidden="true">📍</span>
                    <span>ul. Sportowa 15, 00-001 Warszawa</span>
                </div>
                <div class="contact-detail">
                    <span class="icon" aria-hidden="true">📞</span>
                    <a href="tel:+48221234567" aria-label="Zadzwoń do nas: +48 22 123 45 67">+48 22 123 45 67</a>
                </div>
                <div class="contact-detail">
                    <span class="icon" aria-hidden="true">✉️</span>
                    <a href="mailto:kontakt@pumaflex.pl" aria-label="Napisz email na kontakt@pumaflex.pl">kontakt@pumaflex.pl</a>
                </div>
                <div class="contact-detail">
                    <span class="icon" aria-hidden="true">🕐</span>
                    <span>Pon–Pt: 5:00–23:00 | Sob–Nd: 7:00–22:00</span>
                </div>
            </div>

            <!-- Formularz kontaktowy -->
            <div>
                <?php
                $contactSuccess = getFlash('contact_success');
                $contactError   = getFlash('contact_error');
                ?>
                <?php if ($contactSuccess): ?>
                    <div class="alert alert-success" role="alert"><?= e($contactSuccess) ?></div>
                <?php endif; ?>
                <?php if ($contactError): ?>
                    <div class="alert alert-error" role="alert"><?= e($contactError) ?></div>
                <?php endif; ?>

                <form
                    action="kontakt_action.php"
                    method="POST"
                    novalidate
                    aria-label="Formularz kontaktowy PUMA FLEX"
                >
                    <!-- Token CSRF -->
                    <?php
                    if (empty($_SESSION['csrf_token'])) {
                        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                    }
                    ?>
                    <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                    <div class="form-group">
                        <label for="contact-name">Imię i nazwisko <span aria-hidden="true">*</span></label>
                        <input
                            type="text"
                            id="contact-name"
                            name="name"
                            placeholder="Jan Kowalski"
                            required
                            maxlength="100"
                            autocomplete="name"
                            aria-required="true"
                        >
                    </div>

                    <div class="form-group">
                        <label for="contact-email">Adres e-mail <span aria-hidden="true">*</span></label>
                        <input
                            type="email"
                            id="contact-email"
                            name="email"
                            placeholder="jan@example.com"
                            required
                            maxlength="120"
                            autocomplete="email"
                            aria-required="true"
                        >
                    </div>

                    <div class="form-group">
                        <label for="contact-message">Wiadomość <span aria-hidden="true">*</span></label>
                        <textarea
                            id="contact-message"
                            name="message"
                            rows="5"
                            placeholder="Napisz, w czym możemy pomóc..."
                            required
                            maxlength="2000"
                            aria-required="true"
                        ></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-full" aria-label="Wyślij wiadomość kontaktową">
                        WYŚLIJ WIADOMOŚĆ
                    </button>
                </form>
            </div>
        </div>
    </section>
</main>

<?php require_once 'includes/footer.php'; ?>

<script>
// Hamburger menu toggle
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');

toggle.addEventListener('click', function () {
    const isOpen = navLinks.classList.toggle('open');
    this.setAttribute('aria-expanded', isOpen.toString());
    this.setAttribute('aria-label', isOpen ? 'Zamknij menu' : 'Otwórz menu nawigacyjne');
});

// Zamknij menu po kliknięciu w link
navLinks.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('click', function () {
        navLinks.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Otwórz menu nawigacyjne');
    });
});
</script>
</body>
</html>