<?php
/**
 * includes/header.php
 * Reużywalny nagłówek (nav) serwisu.
 * Zmienna $pageTitle musi być ustawiona przed dołączeniem tego pliku.
 */

if (session_status() === PHP_SESSION_NONE) {
    require_once __DIR__ . '/auth.php';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PUMA FLEX – Ekskluzywna siłownia premium. Sprzęt klasy światowej, trenerzy elity, strefa VIP.">
    <title><?= isset($pageTitle) ? e($pageTitle) . ' | PUMA FLEX' : 'PUMA FLEX – Siłownia Premium' ?></title>
    <link rel="icon" href="assets/img/logo.png" type="image/png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Nawigacja główna -->
<nav class="site-nav" role="navigation" aria-label="Nawigacja główna">
    <!-- Logo -->
    <a href="index.php" class="nav-logo" aria-label="PUMA FLEX – strona główna">
        <img src="assets/img/logo.png" alt="Logo PUMA FLEX – puma trzymająca hantle">
        <span class="nav-logo-text">PUMA FLEX</span>
    </a>

    <!-- Hamburger (mobile) -->
    <button
        class="nav-hamburger"
        id="nav-toggle"
        aria-expanded="false"
        aria-controls="nav-links"
        aria-label="Otwórz menu nawigacyjne"
    >
        <span></span>
        <span></span>
        <span></span>
    </button>

    <!-- Linki -->
    <ul class="nav-links" id="nav-links" role="list">
        <li><a href="karnety.php"  aria-label="Karnety – sprawdź ofertę">Karnety</a></li>
        <li><a href="trenerzy.php" aria-label="Nasi trenerzy">Trenerzy</a></li>
        <li><a href="grafik.php"   aria-label="Grafik zajęć">Grafik</a></li>
        <li><a href="index.php#kontakt" aria-label="Kontakt – przewiń do formularza">Kontakt</a></li>

        <?php if (isLoggedIn()): ?>
            <li><a href="profil.php" aria-label="Twój profil">Profil</a></li>
            <?php if (isAdmin()): ?>
                <li><a href="admin/index.php" aria-label="Panel administratora">Admin</a></li>
            <?php endif; ?>
            <li>
                <a href="logout.php"
                   class="nav-btn-login"
                   aria-label="Wyloguj się z konta">
                    Wyloguj
                </a>
            </li>
        <?php else: ?>
            <li>
                <a href="login.php"
                   class="nav-btn-login"
                   aria-label="Zaloguj się lub zarejestruj">
                    Login
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>