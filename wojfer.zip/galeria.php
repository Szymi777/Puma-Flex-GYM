<?php
/**
 * galeria.php – Galeria sprzętu siłowni.
 * Placeholdery: assets/img/sprzet1.jpg – sprzet8.jpg
 */
require_once 'includes/auth.php';
$pageTitle = 'Galeria Sprzętu';

// Definicja galerii – wystarczy podmienić pliki graficzne o tych nazwach
$galeria = [
    ['plik' => 'assets/img/sprzet1.jpg', 'opis' => 'Maszyny do wyciskania klatki piersiowej Technogym'],
    ['plik' => 'assets/img/sprzet2.jpg', 'opis' => 'Stanowiska do martwego ciągu i przysiadów'],
    ['plik' => 'assets/img/sprzet3.jpg', 'opis' => 'Strefa cardio – bieżnie i rowery eliptyczne'],
    ['plik' => 'assets/img/sprzet4.jpg', 'opis' => 'Hammer Strength – maszyny do ćwiczeń izolowanych'],
    ['plik' => 'assets/img/sprzet5.jpg', 'opis' => 'Wolne ciężary – hantle 1–60 kg'],
    ['plik' => 'assets/img/sprzet6.jpg', 'opis' => 'Klatka wielofunkcyjna i wyciągi linkowe'],
    ['plik' => 'assets/img/sprzet7.jpg', 'opis' => 'Strefa crossfit – kettlebells i liny bojowe'],
    ['plik' => 'assets/img/sprzet8.jpg', 'opis' => 'Strefa rozciągania i mobilności'],
];

require_once 'includes/header.php';
?>

<main>
<section class="gallery-section" aria-labelledby="gallery-title">
    <h2 class="section-title" id="gallery-title">Sprzęt <span class="gold">Klasy Światowej</span></h2>
    <p style="text-align:center;color:var(--gray);margin-top:-40px;margin-bottom:60px;font-size:16px;">
        Ponad 200 stanowisk treningowych. Najnowsze maszyny Technogym i Hammer Strength.
    </p>

    <div class="gallery-grid" role="list" aria-label="Galeria sprzętu siłowni PUMA FLEX">
        <?php foreach ($galeria as $idx => $item): ?>
            <figure
                class="gallery-item"
                role="listitem"
                tabindex="0"
                aria-label="Sprzęt <?= $idx + 1 ?>: <?= e($item['opis']) ?>"
            >
                <img
                    src="<?= e($item['plik']) ?>"
                    alt="<?= e($item['opis']) ?> w siłowni PUMA FLEX"
                    loading="lazy"
                    onerror="this.parentElement.style.display='none'"
                >
                <figcaption class="gallery-overlay">
                    <p><?= e($item['opis']) ?></p>
                </figcaption>
            </figure>
        <?php endforeach; ?>
    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>