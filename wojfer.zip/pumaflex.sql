-- ============================================================
-- PUMA FLEX – Skrypt bazy danych
-- Import w phpMyAdmin: Bazy danych > Importuj > wybierz plik
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- Tworzenie bazy (jeśli nie istnieje)
CREATE DATABASE IF NOT EXISTS `pumaflex`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `pumaflex`;

-- ============================================================
-- TABELA: uzytkownicy
-- role: 'user' = zwykły użytkownik, 'admin' = administrator
-- ============================================================
CREATE TABLE IF NOT EXISTS `uzytkownicy` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `imie`       VARCHAR(60)  NOT NULL DEFAULT '',
  `nazwisko`   VARCHAR(60)  NOT NULL DEFAULT '',
  `email`      VARCHAR(120) NOT NULL,
  `haslo`      VARCHAR(255) NOT NULL,
  `rola`       ENUM('user','admin') NOT NULL DEFAULT 'user',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Domyślny administrator (hasło: Admin1234!)
-- Hash wygenerowany przez password_hash('Admin1234!', PASSWORD_DEFAULT)
INSERT INTO `uzytkownicy` (`imie`, `nazwisko`, `email`, `haslo`, `rola`) VALUES
('Admin', 'PumaFlex', 'admin@pumaflex.pl',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uAnFm/DVO',
 'admin');

-- ============================================================
-- TABELA: trenerzy
-- ============================================================
CREATE TABLE IF NOT EXISTS `trenerzy` (
  `id`              INT(11)      NOT NULL AUTO_INCREMENT,
  `imie_nazwisko`   VARCHAR(100) NOT NULL,
  `specjalizacja`   VARCHAR(150) NOT NULL,
  `opis`            TEXT         NOT NULL,
  `zdjecie`         VARCHAR(255) NOT NULL DEFAULT 'assets/img/trener1.jpg',
  `aktywny`         TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `trenerzy` (`imie_nazwisko`, `specjalizacja`, `opis`, `zdjecie`) VALUES
('Adam Kowalczyk',   'Trening Siłowy & Sylwetka',
 '12 lat doświadczenia w przygotowaniu sylwetkowym. Trzykrotny Mistrz Polski w kulturystyce klasycznej. Specjalizuje się w programowaniu treningów pod konkretne cele sylwetkowe i siłowe.',
 'assets/img/trener1.jpg'),
('Karolina Nowak',   'Trening Funkcjonalny & Mobility',
 'Certyfikowana trenerka FMS i TRX. Ekspertka w modelowaniu sylwetki i poprawie mobilności stawów. Pomogła ponad 300 klientkom osiągnąć wymarzoną formę.',
 'assets/img/trener2.jpg'),
('Michał Zieliński',  'CrossFit & Wytrzymałość',
 'Zawodnik CrossFit z 8-letnim stażem. Specjalista przygotowania motorycznego dla sportowców. Trener kadry narodowej w trójboju siłowym.',
 'assets/img/trener3.jpg'),
('Natalia Wiśniewska','Fitness & Dietetyka',
 'Licencjonowana dietetyk i trenerka personalna. Autorka programu "Body Reset 12 tygodni". Łączy wiedzę żywieniową z zaawansowanym treningiem metabolicznym.',
 'assets/img/trener4.jpg'),
('Krzysztof Dąbrowski','Sporty Walki & Kondycja',
 'Były zawodnik MMA, instruktor kickboxingu i boksu tajskiego. Treningi z Krzysztofem to połączenie intensywnego cardio, techniki i siły.',
 'assets/img/trener5.jpg'),
('Agnieszka Lewandowska','Pilates & Rehabilitacja',
 'Fizjoterapeutka i certyfikowana instruktorka Pilates. Specjalizuje się w treningu posturalnym i rehabilitacji po kontuzjach. Idealna dla osób z problemami kręgosłupa.',
 'assets/img/trener6.jpg');

-- ============================================================
-- TABELA: dostepnosc_trenerow
-- Definiuje dostępne sloty godzinowe dla każdego trenera
-- ============================================================
CREATE TABLE IF NOT EXISTS `dostepnosc_trenerow` (
  `id`          INT(11)  NOT NULL AUTO_INCREMENT,
  `trener_id`   INT(11)  NOT NULL,
  `dzien_tyg`   TINYINT(1) NOT NULL COMMENT '1=Pon, 2=Wt, 3=Sr, 4=Czw, 5=Pt, 6=Sob, 7=Nd',
  `godzina_od`  TIME     NOT NULL,
  `godzina_do`  TIME     NOT NULL,
  PRIMARY KEY (`id`),
  KEY `trener_id` (`trener_id`),
  CONSTRAINT `fk_dostepnosc_trener`
    FOREIGN KEY (`trener_id`) REFERENCES `trenerzy` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Przykładowe sloty dostępności (każdy trener: pon-pt różne godziny)
INSERT INTO `dostepnosc_trenerow` (`trener_id`, `dzien_tyg`, `godzina_od`, `godzina_do`) VALUES
(1, 1, '08:00', '16:00'),(1, 2, '08:00', '16:00'),(1, 3, '08:00', '16:00'),
(1, 4, '08:00', '16:00'),(1, 5, '08:00', '14:00'),
(2, 1, '10:00', '18:00'),(2, 2, '10:00', '18:00'),(2, 3, '10:00', '18:00'),
(2, 4, '10:00', '18:00'),(2, 5, '10:00', '16:00'),(2, 6, '09:00', '13:00'),
(3, 1, '06:00', '14:00'),(3, 2, '06:00', '14:00'),(3, 3, '06:00', '14:00'),
(3, 4, '06:00', '14:00'),(3, 5, '06:00', '14:00'),
(4, 2, '12:00', '20:00'),(4, 3, '12:00', '20:00'),(4, 4, '12:00', '20:00'),
(4, 5, '12:00', '20:00'),(4, 6, '10:00', '16:00'),
(5, 1, '14:00', '21:00'),(5, 2, '14:00', '21:00'),(5, 3, '14:00', '21:00'),
(5, 4, '14:00', '21:00'),(5, 5, '14:00', '21:00'),(5, 6, '10:00', '18:00'),
(6, 1, '09:00', '17:00'),(6, 2, '09:00', '17:00'),(6, 3, '09:00', '17:00'),
(6, 4, '09:00', '17:00'),(6, 5, '09:00', '15:00');

-- ============================================================
-- TABELA: rezerwacje
-- status: 'oczekujaca', 'potwierdzona', 'odwolana'
-- ============================================================
CREATE TABLE IF NOT EXISTS `rezerwacje` (
  `id`           INT(11)      NOT NULL AUTO_INCREMENT,
  `uzytkownik_id` INT(11)     NOT NULL,
  `trener_id`    INT(11)      NOT NULL,
  `data_treningu` DATE        NOT NULL,
  `godzina_od`   TIME        NOT NULL,
  `godzina_do`   TIME        NOT NULL,
  `notatka`      TEXT         DEFAULT NULL,
  `status`       ENUM('oczekujaca','potwierdzona','odwolana') NOT NULL DEFAULT 'oczekujaca',
  `created_at`   TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uzytkownik_id` (`uzytkownik_id`),
  KEY `trener_id` (`trener_id`),
  CONSTRAINT `fk_rez_uzytkownik`
    FOREIGN KEY (`uzytkownik_id`) REFERENCES `uzytkownicy` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rez_trener`
    FOREIGN KEY (`trener_id`) REFERENCES `trenerzy` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABELA: kontakt
-- ============================================================
CREATE TABLE IF NOT EXISTS `kontakt` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `email`      VARCHAR(120) NOT NULL,
  `message`    TEXT         NOT NULL,
  `przeczytana` TINYINT(1)  NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;