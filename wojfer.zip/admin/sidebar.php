<?php
/**
 * admin/sidebar.php – Reużywalny sidebar panelu admina.
 */
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<nav class="admin-sidebar" role="navigation" aria-label="Menu panelu administratora">
    <div class="admin-sidebar-title">⚙️ Panel Admina</div>
    <ul class="admin-nav" role="list">
        <li>
            <a href="index.php"
               class="<?= $currentPage === 'index.php' ? 'active' : '' ?>"
               aria-label="Dashboard – statystyki serwisu"
               aria-current="<?= $currentPage === 'index.php' ? 'page' : 'false' ?>">
                <span class="nav-icon" aria-hidden="true">📊</span> Dashboard
            </a>
        </li>
        <li>
            <a href="users.php"
               class="<?= $currentPage === 'users.php' ? 'active' : '' ?>"
               aria-label="Zarządzanie użytkownikami"
               aria-current="<?= $currentPage === 'users.php' ? 'page' : 'false' ?>">
                <span class="nav-icon" aria-hidden="true">👥</span> Użytkownicy
            </a>
        </li>
        <li>
            <a href="trainers.php"
               class="<?= $currentPage === 'trainers.php' ? 'active' : '' ?>"
               aria-label="Zarządzanie trenerami"
               aria-current="<?= $currentPage === 'trainers.php' ? 'page' : 'false' ?>">
                <span class="nav-icon" aria-hidden="true">🏋️</span> Trenerzy
            </a>
        </li>
        <li>
            <a href="reservations.php"
               class="<?= $currentPage === 'reservations.php' ? 'active' : '' ?>"
               aria-label="Zarządzanie rezerwacjami"
               aria-current="<?= $currentPage === 'reservations.php' ? 'page' : 'false' ?>">
                <span class="nav-icon" aria-hidden="true">📅</span> Rezerwacje
            </a>
        </li>
        <li>
            <a href="messages.php"
               class="<?= $currentPage === 'messages.php' ? 'active' : '' ?>"
               aria-label="Wiadomości kontaktowe"
               aria-current="<?= $currentPage === 'messages.php' ? 'page' : 'false' ?>">
                <span class="nav-icon" aria-hidden="true">✉️</span> Wiadomości
            </a>
        </li>
        <li style="margin-top:auto;padding-top:20px;border-top:1px solid rgba(212,175,55,0.1);">
            <a href="../index.php" aria-label="Wróć do strony głównej serwisu">
                <span class="nav-icon" aria-hidden="true">🏠</span> Strona główna
            </a>
        </li>
        <li>
            <a href="../logout.php" aria-label="Wyloguj się z panelu administratora">
                <span class="nav-icon" aria-hidden="true">🚪</span> Wyloguj
            </a>
        </li>
    </ul>
</nav>