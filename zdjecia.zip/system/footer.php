<?php
/**
 * includes/footer.php
 */
?>
<footer class="site-footer" role="contentinfo">
    <div class="footer-grid">
        <div class="footer-brand">
            <span class="nav-logo-text gold">PUMA FLEX</span>
            <p>Ekskluzywna siłownia premium w Warszawie.</p>
        </div>

        <nav aria-label="Nawigacja w stopce">
            <h4>Nawigacja</h4>
            <ul>
                <li><a href="/pumaflex/index.php">Strona główna</a></li>
                <li><a href="/pumaflex/karnety.php">Karnety</a></li>
                <li><a href="/pumaflex/trenerzy.php">Trenerzy</a></li>
                <li><a href="/pumaflex/grafik.php">Grafik zajęć</a></li>
                <li><a href="/pumaflex/galeria.php">Galeria sprzętu</a></li>
                <li><a href="/pumaflex/vip.php">Strefa VIP</a></li>
            </ul>
        </nav>

        <div class="footer-col">
            <h4>Kontakt</h4>
            <ul>
                <li><a href="tel:+48221234567">+48 22 123 45 67</a></li>
                <li><a href="mailto:kontakt@pumaflex.pl">kontakt@pumaflex.pl</a></li>
                <li><span>ul. Sportowa 15, Warszawa</span></li>
                <li><span>Pon–Pt: 5:00–23:00</span></li>
                <li><span>Sob–Nd: 7:00–22:00</span></li>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> PUMA FLEX. Wszelkie prawa zastrzeżone.</p>
        <p>Projekt i realizacja: PUMA FLEX Dev Team</p>
    </div>
</footer>