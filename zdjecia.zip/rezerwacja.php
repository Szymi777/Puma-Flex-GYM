<?php
/**
 * rezerwacja.php
 * Formularz rezerwacji treningu personalnego.
 * Walidacja konfliktu terminów przez SQL (Prepared Statement).
 */
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Tylko zalogowani użytkownicy
requireLogin('login.php');

$pageTitle = 'Rezerwacja Treningu';
$errors    = [];
$success   = false;

// Generuj CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Pobierz listę aktywnych trenerów
$stmtT = $pdo->prepare('SELECT id, imie_nazwisko, specjalizacja FROM trenerzy WHERE aktywny = 1 ORDER BY imie_nazwisko ASC');
$stmtT->execute();
$trenerzy = $stmtT->fetchAll();

// Wstępnie wybrany trener (z parametru URL, np. z linku na stronie trenerzy.php)
$preTrenerId = isset($_GET['trener']) ? (int)$_GET['trener'] : 0;

// ----------------------------------------------------------------
// Dostępne godziny (pełne godziny od 6:00 do 21:00)
// ----------------------------------------------------------------
$dostepneGodziny = [];
for ($h = 6; $h <= 21; $h++) {
    $dostepneGodziny[] = sprintf('%02d:00', $h);
}

// ----------------------------------------------------------------
// Obsługa wysłanego formularza
// ----------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Weryfikacja CSRF
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $errors[] = 'Nieprawidłowe żądanie. Odśwież stronę i spróbuj ponownie.';
    } else {
        $trenerId   = (int)($_POST['trener_id'] ?? 0);
        $data       = trim($_POST['data_treningu'] ?? '');
        $godzinaOd  = trim($_POST['godzina_od'] ?? '');
        $notatka    = trim($_POST['notatka'] ?? '');

        // --- Walidacja danych wejściowych ---
        if ($trenerId <= 0) {
            $errors[] = 'Wybierz trenera.';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
            $errors[] = 'Wybierz prawidłową datę treningu.';
        } elseif (strtotime($data) < strtotime('today')) {
            $errors[] = 'Data treningu nie może być z przeszłości.';
        } elseif (strtotime($data) > strtotime('+3 months')) {
            $errors[] = 'Rezerwacja możliwa maksymalnie na 3 miesiące do przodu.';
        }
        if (!in_array($godzinaOd, $dostepneGodziny, true)) {
            $errors[] = 'Wybierz prawidłową godzinę treningu.';
        }
        if (mb_strlen($notatka) > 500) {
            $errors[] = 'Notatka jest zbyt długa (max. 500 znaków).';
        }

        // Godzina zakończenia = godzina rozpoczęcia + 1h
        $godzinaDoTs = strtotime($godzinaOd) + 3600;
        $godzinaDo   = date('H:i', $godzinaDoTs);

        if (empty($errors)) {
            // --- Sprawdź czy trener istnieje i jest aktywny ---
            $chkT = $pdo->prepare('SELECT id, imie_nazwisko FROM trenerzy WHERE id = :id AND aktywny = 1');
            $chkT->execute([':id' => $trenerId]);
            $trenerRow = $chkT->fetch();
            if (!$trenerRow) {
                $errors[] = 'Wybrany trener nie istnieje lub jest niedostępny.';
            }
        }

        if (empty($errors)) {
            // --- Sprawdź dostępność trenera w danym dniu tygodnia ---
            $dzienTyg = (int)date('N', strtotime($data)); // 1=Pon, 7=Nd

            $chkAvail = $pdo->prepare(
                'SELECT id FROM dostepnosc_trenerow
                  WHERE trener_id = :tid
                    AND dzien_tyg = :dzien
                    AND godzina_od <= :god_od
                    AND godzina_do >= :god_do
                  LIMIT 1'
            );
            $chkAvail->execute([
                ':tid'    => $trenerId,
                ':dzien'  => $dzienTyg,
                ':god_od' => $godzinaOd . ':00',
                ':god_do' => $godzinaDo . ':00',
            ]);
            if (!$chkAvail->fetch()) {
                $errors[] = 'Trener nie jest dostępny w wybranym dniu lub godzinie. Sprawdź grafik dostępności.';
            }
        }

        if (empty($errors)) {
            // --- Sprawdź konflikty terminów (SQL Injection Protection: Prepared Statement) ---
            $chkConflict = $pdo->prepare(
                'SELECT id FROM rezerwacje
                  WHERE trener_id = :tid
                    AND data_treningu = :data
                    AND status != "odwolana"
                    AND (
                        (godzina_od < :god_do AND godzina_do > :god_od)
                    )
                  LIMIT 1'
            );
            $chkConflict->execute([
                ':tid'    => $trenerId,
                ':data'   => $data,
                ':god_od' => $godzinaOd . ':00',
                ':god_do' => $godzinaDo . ':00',
            ]);

            if ($chkConflict->fetch()) {
                $errors[] = 'Ten termin jest już zajęty (' . e($data) . ' godz. ' . e($godzinaOd) . '–' . e($godzinaDo) . '). '
                           . 'Wybierz inną godzinę lub inny dzień.';
            }
        }

        // Sprawdź czy użytkownik nie ma już rezerwacji z tym trenerem tego samego dnia
        if (empty($errors)) {
            $chkUser = $pdo->prepare(
                'SELECT id FROM rezerwacje
                  WHERE uzytkownik_id = :uid
                    AND trener_id = :tid
                    AND data_treningu = :data
                    AND status != "odwolana"
                  LIMIT 1'
            );
            $chkUser->execute([
                ':uid'  => $_SESSION['user_id'],
                ':tid'  => $trenerId,
                ':data' => $data,
            ]);
            if ($chkUser->fetch()) {
                $errors[] = 'Masz już rezerwację z tym trenerem w tym dniu. Wybierz inny dzień.';
            }
        }

        // --- Zapisz rezerwację ---
        if (empty($errors)) {
            $ins = $pdo->prepare(
                'INSERT INTO rezerwacje
                    (uzytkownik_id, trener_id, data_treningu, godzina_od, godzina_do, notatka, status)
                 VALUES
                    (:uid, :tid, :data, :god_od, :god_do, :notatka, "oczekujaca")'
            );
            $ins->execute([
                ':uid'     => (int)$_SESSION['user_id'],
                ':tid'     => $trenerId,
                ':data'    => $data,
                ':god_od'  => $godzinaOd . ':00',
                ':god_do'  => $godzinaDo . ':00',
                ':notatka' => $notatka,
            ]);

            // Regeneruj CSRF po udanym zapisie
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $success = true;
        }
    }
}

require_once 'includes/header.php';
?>

<main>
<section class="rezerwacja-section" aria-labelledby="rez-title">
    <div class="rezerwacja-container">
        <h2 class="section-title" id="rez-title">Zarezerwuj <span class="gold">Trening</span></h2>

        <?php if ($success): ?>
            <div class="alert alert-success" role="alert" aria-live="polite">
                ✅ Rezerwacja została złożona pomyślnie! Trener potwierdzi termin w ciągu 24 godzin.
                Sprawdź swoje rezerwacje w <a href="profil.php" style="color:var(--gold);">profilu</a>.
            </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error" role="alert" aria-live="assertive">
                <?php foreach ($errors as $err): ?>
                    <p><?= e($err) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="admin-form" style="max-width:100%;">
            <form method="POST" action="rezerwacja.php" novalidate aria-label="Formularz rezerwacji treningu personalnego">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <!-- Wybór trenera -->
                <div class="form-group">
                    <label for="trener-select">Wybierz trenera <span aria-hidden="true">*</span></label>
                    <select
                        id="trener-select"
                        name="trener_id"
                        required
                        aria-required="true"
                        aria-label="Wybierz trenera do treningu personalnego"
                    >
                        <option value="">-- Wybierz trenera --</option>
                        <?php foreach ($trenerzy as $t): ?>
                            <option
    value="<?= (int)$t['id'] ?>"
    <?php
        // Bezpieczne pobranie wartości – najpierw ?? potem rzutowanie
        $selectedTrener = (int)($_POST['trener_id'] ?? $preTrenerId);
        echo $selectedTrener === (int)$t['id'] ? 'selected' : '';
    ?>
>
                                <?= e($t['imie_nazwisko']) ?> – <?= e($t['specjalizacja']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Data treningu -->
                <div class="form-group">
                    <label for="data-treningu">Data treningu <span aria-hidden="true">*</span></label>
                    <input
                        type="date"
                        id="data-treningu"
                        name="data_treningu"
                        required
                        aria-required="true"
                        min="<?= date('Y-m-d') ?>"
                        max="<?= date('Y-m-d', strtotime('+3 months')) ?>"
                        value="<?= e($_POST['data_treningu'] ?? '') ?>"
                        aria-label="Wybierz datę treningu personalnego"
                    >
                </div>

                <!-- Godzina -->
                <div class="form-group">
                    <label for="godzina-od">Godzina rozpoczęcia <span aria-hidden="true">*</span></label>
                    <select
                        id="godzina-od"
                        name="godzina_od"
                        required
                        aria-required="true"
                        aria-label="Wybierz godzinę rozpoczęcia treningu (czas trwania: 1 godzina)"
                    >
                        <option value="">-- Wybierz godzinę --</option>
                        <?php foreach ($dostepneGodziny as $g): ?>
                            <option
                                value="<?= e($g) ?>"
                                <?= ($_POST['godzina_od'] ?? '') === $g ? 'selected' : '' ?>
                            >
                                <?= e($g) ?> – <?= date('H:i', strtotime($g) + 3600) ?>
                                (1 godzina)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Notatka -->
                <div class="form-group">
                    <label for="notatka-rez">Notatka dla trenera (opcjonalnie)</label>
                    <textarea
                        id="notatka-rez"
                        name="notatka"
                        rows="4"
                        placeholder="Np. cel treningu, kontuzje, preferencje..."
                        maxlength="500"
                        aria-label="Dodatkowa notatka dla trenera – opcjonalne"
                    ><?= e($_POST['notatka'] ?? '') ?></textarea>
                </div>

                <div style="display:flex;gap:16px;flex-wrap:wrap;">
                    <button type="submit" class="btn btn-primary" aria-label="Zatwierdź rezerwację treningu">
                        ZAREZERWUJ TERMIN
                    </button>
                    <a href="trenerzy.php" class="btn btn-secondary" aria-label="Wróć do listy trenerów">
                        WRÓĆ DO TRENERÓW
                    </a>
                </div>
            </form>
        </div>
    </div>
</section>
</main>

<?php require_once 'includes/footer.php'; ?>
<script>
const toggle = document.getElementById('nav-toggle');
const navLinks = document.getElementById('nav-links');
if (toggle && navLinks) {
    toggle.addEventListener('click', function () {
        const isOpen = navLinks.classList.toggle('open');
        this.setAttribute('aria-expanded', isOpen.toString());
    });
}
</script>
</body>
</html>